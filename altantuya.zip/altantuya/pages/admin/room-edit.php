<?php
$pageTitle = 'Админ - Өрөө засах';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/database.php';
requireAdmin();

$base = getBaseUrl();
$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: ' . $base . '/pages/admin/rooms.php');
    exit;
}

$stmt = $db->prepare('SELECT * FROM rooms WHERE id = ?');
$stmt->execute([$id]);
$room = $stmt->fetch();

if (!$room) {
    header('Location: ' . $base . '/pages/admin/rooms.php');
    exit;
}

$imgStmt = $db->prepare('SELECT * FROM room_images WHERE room_id = ?');
$imgStmt->execute([$id]);
$existingImages = $imgStmt->fetchAll();

$error = '';

if (isset($_GET['delete_image'])) {
    $imgId = intval($_GET['delete_image']);
    $img = $db->prepare('SELECT * FROM room_images WHERE id = ? AND room_id = ?');
    $img->execute([$imgId, $id]);
    $imgData = $img->fetch();
    if ($imgData) {
        $imgPath = __DIR__ . '/../../uploads/rooms/' . $imgData['image_path'];
        if (file_exists($imgPath)) unlink($imgPath);
        $db->prepare('DELETE FROM room_images WHERE id = ?')->execute([$imgId]);
    }
    header("Location: " . $base . "/pages/admin/room-edit.php?id=$id");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $price = intval($_POST['price'] ?? 0);
    $capacity = intval($_POST['capacity'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    $status = $_POST['status'] ?? 'available';
    $is_vip = isset($_POST['is_vip']) ? 1 : 0;

    if (empty($name) || $price <= 0) {
        $error = 'Өрөөний нэр болон үнийг зөв оруулна уу';
    } else {
        $uploadDir = __DIR__ . '/../../uploads/rooms/';
        $featuredImage = $room['featured_image'];

        if (!empty($_FILES['featured_image']['name'])) {
            $ext = strtolower(pathinfo($_FILES['featured_image']['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            if (in_array($ext, $allowed)) {
                if ($featuredImage && file_exists($uploadDir . $featuredImage)) {
                    unlink($uploadDir . $featuredImage);
                }
                $featuredImage = 'featured_' . time() . '_' . uniqid() . '.' . $ext;
                move_uploaded_file($_FILES['featured_image']['tmp_name'], $uploadDir . $featuredImage);
            }
        }

            $stmt = $db->prepare('UPDATE rooms SET name = ?, price = ?, capacity = ?, description = ?, featured_image = ?, status = ?, is_vip = ? WHERE id = ?');
            $stmt->execute([$name, $price, $capacity, $description, $featuredImage, $status, $is_vip, $id]);

        if (!empty($_FILES['other_images']['name'][0])) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            foreach ($_FILES['other_images']['name'] as $i => $fileName) {
                if ($_FILES['other_images']['error'][$i] === UPLOAD_ERR_OK) {
                    $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                    if (in_array($ext, $allowed)) {
                        $newName = 'room_' . $id . '_' . time() . '_' . $i . '.' . $ext;
                        move_uploaded_file($_FILES['other_images']['tmp_name'][$i], $uploadDir . $newName);
                        $db->prepare('INSERT INTO room_images (room_id, image_path) VALUES (?, ?)')->execute([$id, $newName]);
                    }
                }
            }
        }

        header('Location: ' . $base . '/pages/admin/rooms.php?updated=1');
        exit;
    }
}

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container">
    <div class="admin-page">
        <?php include __DIR__ . '/../../includes/admin-sidebar.php'; ?>

        <div class="admin-content">
            <div class="admin-content-header">
                <h1 class="admin-title">
                    <i class="fas fa-edit"></i> Өрөө засах
                </h1>
                <a href="<?= $baseUrl ?>/pages/admin/rooms.php" class="btn btn-outline">
                    <i class="fas fa-arrow-left"></i> Буцах
                </a>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?= $error ?>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" class="room-form">
                <div class="form-card">
                    <h3><i class="fas fa-info-circle"></i> Үндсэн мэдээлэл</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="name">Өрөөний нэр <span class="required">*</span></label>
                            <input type="text" id="name" name="name" class="form-control"
                                   required value="<?= htmlspecialchars($room['name']) ?>">
                        </div>
                        <div class="form-group">
                            <label for="price">Үнэ (₮/цаг) <span class="required">*</span></label>
                            <input type="number" id="price" name="price" class="form-control"
                                   required min="1" value="<?= $room['price'] ?>">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Багтаамж (хүний тоо)</label>
                            <input type="number" name="capacity" class="form-control" min="0" value="<?= $room['capacity'] ?? 0 ?>">
                        </div>
                        <div class="form-group">
                            <label>Төлөв</label>
                            <select name="status" class="form-control">
                                <option value="available" <?= ($room['status'] ?? '') === 'available' ? 'selected' : '' ?>>Боломжтой</option>
                                <option value="unavailable" <?= ($room['status'] ?? '') === 'unavailable' ? 'selected' : '' ?>>Боломжгүй</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="vip-checkbox-label">
                            <input type="checkbox" name="is_vip" value="1" <?= !empty($room['is_vip']) ? 'checked' : '' ?>>
                            <span class="vip-checkbox-box"><i class="fas fa-crown"></i></span>
                            <span>VIP өрөө</span>
                        </label>
                    </div>
                    <div class="form-group">
                        <label for="description">Дэлгэрэнгүй мэдээлэл</label>
                        <textarea id="description" name="description" class="form-control" rows="5"><?= htmlspecialchars($room['description']) ?></textarea>
                    </div>
                </div>

                <div class="form-card">
                    <h3><i class="fas fa-image"></i> Үндсэн зураг</h3>
                    <?php if ($room['featured_image']): ?>
                        <div class="current-image">
                            <img src="<?= $baseUrl ?>/uploads/rooms/<?= htmlspecialchars($room['featured_image']) ?>" alt="">
                            <p class="form-help">Шинэ зураг сонговол хуучин зураг солигдоно</p>
                        </div>
                    <?php endif; ?>
                    <div class="upload-area" id="featuredUploadArea">
                        <input type="file" id="featured_image" name="featured_image" accept="image/*"
                               onchange="previewFeaturedImage(this)">
                        <div class="upload-placeholder" id="featuredPlaceholder">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <p><?= $room['featured_image'] ? 'Шинэ зураг сонгох' : 'Зураг сонгоно уу' ?></p>
                            <span>JPG, PNG, GIF, WEBP</span>
                        </div>
                        <div class="upload-preview" id="featuredPreview" style="display:none;">
                            <img id="featuredPreviewImg" src="" alt="">
                            <button type="button" class="btn btn-sm btn-danger remove-preview"
                                    onclick="removeFeaturedImage()">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="form-card">
                    <h3><i class="fas fa-images"></i> Бусад зурагнууд</h3>

                    <?php if (!empty($existingImages)): ?>
                        <div class="existing-images-grid">
                            <?php foreach ($existingImages as $img): ?>
                                <div class="existing-image-item">
                                    <img src="<?= $baseUrl ?>/uploads/rooms/<?= htmlspecialchars($img['image_path']) ?>" alt="">
                                    <a href="<?= $baseUrl ?>/pages/admin/room-edit.php?id=<?= $id ?>&delete_image=<?= $img['id'] ?>"
                                       class="btn btn-sm btn-danger remove-existing"
                                       onclick="return confirm('Энэ зургийг устгах уу?')">
                                        <i class="fas fa-times"></i>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <p class="form-help">Нэмэлт зураг оруулах (хэдэн ч зураг оруулах боломжтой)</p>
                    <div class="upload-area" id="otherUploadArea">
                        <input type="file" id="other_images" name="other_images[]" accept="image/*" multiple
                               onchange="previewOtherImages(this)">
                        <div class="upload-placeholder" id="otherPlaceholder">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <p>Зургуудаа сонгоно уу (олон зураг сонгож болно)</p>
                            <span>JPG, PNG, GIF, WEBP</span>
                        </div>
                    </div>
                    <div class="upload-previews-grid" id="otherPreviews"></div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-save"></i> Хадгалах
                    </button>
                    <a href="<?= $baseUrl ?>/pages/admin/rooms.php" class="btn btn-outline btn-lg">Цуцлах</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
