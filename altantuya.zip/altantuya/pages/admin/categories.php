<?php
$pageTitle = 'Админ - Ангилал';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/database.php';
requireAdmin();

$base = getBaseUrl();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');

    if ($action === 'add' && !empty($name)) {
        $db->prepare('INSERT INTO categories (name, description) VALUES (?, ?)')->execute([$name, $description]);
        $success = 'Ангилал амжилттай нэмэгдлээ';
    } elseif ($action === 'edit') {
        $id = intval($_POST['id'] ?? 0);
        if ($id && !empty($name)) {
            $db->prepare('UPDATE categories SET name = ?, description = ? WHERE id = ?')->execute([$name, $description, $id]);
            $success = 'Ангилал шинэчлэгдлээ';
        }
    }
}

if (isset($_GET['delete'])) {
    $deleteId = intval($_GET['delete']);
    $db->prepare('DELETE FROM categories WHERE id = ?')->execute([$deleteId]);
    header('Location: ' . $base . '/pages/admin/categories.php?deleted=1');
    exit;
}

if (isset($_GET['deleted'])) $success = 'Ангилал устгагдлаа';

$categories = $db->query('SELECT c.*, (SELECT COUNT(*) FROM products WHERE category_id = c.id) as product_count FROM categories c ORDER BY c.created_at DESC')->fetchAll();
$editCat = null;
if (isset($_GET['edit'])) {
    $editId = intval($_GET['edit']);
    $editCat = $db->prepare('SELECT * FROM categories WHERE id = ?');
    $editCat->execute([$editId]);
    $editCat = $editCat->fetch();
}

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container">
    <div class="admin-page">
        <?php include __DIR__ . '/../../includes/admin-sidebar.php'; ?>

        <div class="admin-content">
            <h1 class="admin-title"><i class="fas fa-tags"></i> Ангилал</h1>

            <?php if ($success): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= $success ?></div>
            <?php endif; ?>

            <div class="form-card" style="margin-bottom: 24px;">
                <h3><i class="fas fa-<?= $editCat ? 'edit' : 'plus-circle' ?>"></i> <?= $editCat ? 'Ангилал засах' : 'Шинэ ангилал нэмэх' ?></h3>
                <form method="POST">
                    <input type="hidden" name="action" value="<?= $editCat ? 'edit' : 'add' ?>">
                    <?php if ($editCat): ?>
                        <input type="hidden" name="id" value="<?= $editCat['id'] ?>">
                    <?php endif; ?>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Ангилалын нэр <span class="required">*</span></label>
                            <input type="text" name="name" class="form-control" required placeholder="Жишээ: Ундаа"
                                   value="<?= htmlspecialchars($editCat['name'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>Тайлбар</label>
                            <input type="text" name="description" class="form-control" placeholder="Товч тайлбар"
                                   value="<?= htmlspecialchars($editCat['description'] ?? '') ?>">
                        </div>
                    </div>
                    <div style="margin-top: 12px; display: flex; gap: 8px;">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> <?= $editCat ? 'Хадгалах' : 'Нэмэх' ?>
                        </button>
                        <?php if ($editCat): ?>
                            <a href="<?= $baseUrl ?>/pages/admin/categories.php" class="btn btn-outline">Цуцлах</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <?php if (empty($categories)): ?>
                <div class="empty-state">
                    <i class="fas fa-tags"></i>
                    <h3>Ангилал бүртгэгдээгүй байна</h3>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Нэр</th>
                                <th>Тайлбар</th>
                                <th>Бараа</th>
                                <th>Үйлдэл</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($categories as $i => $cat): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td><strong><?= htmlspecialchars($cat['name']) ?></strong></td>
                                <td><?= htmlspecialchars($cat['description'] ?? '-') ?></td>
                                <td><span class="badge badge-user"><?= $cat['product_count'] ?></span></td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="<?= $baseUrl ?>/pages/admin/categories.php?edit=<?= $cat['id'] ?>" class="btn btn-sm btn-outline"><i class="fas fa-edit"></i></a>
                                        <a href="<?= $baseUrl ?>/pages/admin/categories.php?delete=<?= $cat['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Устгах уу?')"><i class="fas fa-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
