<?php
$pageTitle = 'Нэвтрэх';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';

$base = getBaseUrl();

if (isLoggedIn()) {
    header('Location: ' . $base . '/');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Бүх талбарыг бөглөнө үү';
    } else {
        $stmt = $db->prepare('SELECT * FROM users WHERE username = ?');
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user'] = [
                'id' => $user['id'],
                'username' => $user['username'],
                'role' => $user['role']
            ];
            if ($user['role'] === 'admin') {
                header('Location: ' . $base . '/pages/admin/dashboard.php');
            } else {
                header('Location: ' . $base . '/');
            }
            exit;
        } else {
            $error = 'Нэвтрэх нэр эсвэл нууц үг буруу байна';
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container">
    <div class="auth-wrapper">
        <div class="auth-card">
            <div class="auth-header">
                <i class="fas fa-microphone-alt auth-icon"></i>
                <h2>Нэвтрэх</h2>
                <p>Тавтай морилно уу</p>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?= $error ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="auth-form">
                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-user"></i> Нэвтрэх нэр
                    </label>
                    <input type="text" id="username" name="username" class="form-control"
                           placeholder="Нэвтрэх нэрээ оруулна уу" required
                           value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="password">
                        <i class="fas fa-lock"></i> Нууц үг
                    </label>
                    <input type="password" id="password" name="password" class="form-control"
                           placeholder="Нууц үгээ оруулна уу" required>
                </div>
                <button type="submit" class="btn btn-primary btn-block btn-lg">
                    <i class="fas fa-sign-in-alt"></i> Нэвтрэх
                </button>
            </form>
            <div class="auth-footer">
                <p>Бүртгэл байхгүй юу? <a href="<?= $baseUrl ?>/pages/register.php">Бүртгүүлэх</a></p>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
