<?php
$pageTitle = 'Алтантуяа Караоке - Нүүр';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/config/settings.php';

$contactConfig = getContactConfig();
$rooms = $db->query("SELECT * FROM rooms ORDER BY created_at DESC")->fetchAll();
foreach ($rooms as &$room) {
    $imgStmt = $db->prepare('SELECT * FROM room_images WHERE room_id = ?');
    $imgStmt->execute([$room['id']]);
    $room['images'] = $imgStmt->fetchAll();
}
unset($room);

$products = $db->query("SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.status = 'active' ORDER BY p.created_at DESC")->fetchAll();
$categories = $db->query("SELECT * FROM categories ORDER BY name")->fetchAll();
?>

<section class="hero">
    <div class="container">
        <div class="hero-content">
            <h1>Алтантуяа <span class="text-gradient">Караоке</span></h1>
            <p class="hero-subtitle">Найз нөхөд, гэр бүлийнхэнтэйгээ хамтдаа дуулж, мартагдашгүй мөчүүдийг бүтээгээрэй</p>
            <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
                <a href="#rooms" class="btn btn-primary btn-lg">
                    <i class="fas fa-door-open"></i> Өрөөнүүд
                </a>
                <a href="#menu" class="btn btn-outline btn-lg">
                    <i class="fas fa-utensils"></i> Бүтээгдэхүүн
                </a>
                <a href="#contact" class="btn btn-outline btn-lg">
                    <i class="fas fa-phone-alt"></i> Холбоо барих
                </a>
            </div>
        </div>
    </div>
</section>

<section id="rooms" class="section">
    <div class="container">
        <div class="section-header">
            <h2>Манай өрөөнүүд</h2>
            <p>Таны сонголтод нийцсэн өрөөг сонгоорой</p>
        </div>

        <?php if (empty($rooms)): ?>
            <div class="empty-state">
                <i class="fas fa-music"></i>
                <h3>Одоогоор өрөө бүртгэгдээгүй байна</h3>
                <p>Удахгүй шинэ өрөөнүүд нэмэгдэнэ</p>
            </div>
        <?php else: ?>
            <div class="rooms-grid">
                <?php foreach ($rooms as $room): $isVip = !empty($room['is_vip']); ?>
                    <div class="room-card <?= $isVip ? 'room-card-vip' : '' ?>">
                        <div class="room-card-image">
                            <?php if ($isVip): ?>
                                <div class="vip-ribbon"><i class="fas fa-crown"></i> VIP</div>
                            <?php endif; ?>
                            <?php if ($room['featured_image']): ?>
                                <img src="<?= $baseUrl ?>/uploads/rooms/<?= htmlspecialchars($room['featured_image']) ?>" alt="<?= htmlspecialchars($room['name']) ?>">
                            <?php else: ?>
                                <div class="room-card-placeholder">
                                    <i class="fas fa-<?= $isVip ? 'crown' : 'microphone-alt' ?>"></i>
                                </div>
                            <?php endif; ?>
                            <div class="room-card-price <?= $isVip ? 'vip-price' : '' ?>">
                                <span><?= number_format($room['price']) ?>₮/цаг</span>
                            </div>
                        </div>
                        <div class="room-card-body">
                            <h3><?php if ($isVip): ?><i class="fas fa-crown" style="color: #F59E0B; margin-right: 6px;"></i><?php endif; ?><?= htmlspecialchars($room['name']) ?></h3>
                            <?php if ($room['capacity']): ?>
                                <small style="color: var(--text-muted);"><i class="fas fa-users"></i> <?= $room['capacity'] ?> хүн</small>
                            <?php endif; ?>
                            <p><?= mb_substr(htmlspecialchars($room['description'] ?? ''), 0, 100) ?>...</p>
                            <div style="display: flex; gap: 8px;">
                                <a href="<?= $baseUrl ?>/pages/room-detail.php?id=<?= $room['id'] ?>" class="btn btn-outline" style="flex:1; justify-content: center;">
                                    Дэлгэрэнгүй <i class="fas fa-arrow-right"></i>
                                </a>
                                <?php if (isLoggedIn()): ?>
                                    <a href="<?= $baseUrl ?>/pages/booking.php?room_id=<?= $room['id'] ?>" class="btn btn-primary" style="flex:1; justify-content: center;">
                                        <i class="fas fa-calendar-check"></i> Захиалах
                                    </a>
                                <?php else: ?>
                                    <a href="<?= $baseUrl ?>/pages/login.php" class="btn btn-primary" style="flex:1; justify-content: center;">
                                        <i class="fas fa-sign-in-alt"></i> Нэвтэрч захиалах
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php if (!empty($products)): ?>
<section id="menu" class="section" style="background: var(--bg-card);">
    <div class="container">
        <div class="section-header">
            <h2>Бараа бүтээгдэхүүн</h2>
            <p>Ундаа, хоол болон бусад бүтээгдэхүүнүүд</p>
        </div>

        <div class="rooms-grid">
            <?php foreach ($products as $p): ?>
                <div class="room-card">
                    <div class="room-card-image" style="height: 180px;">
                        <?php if ($p['image']): ?>
                            <img src="<?= $baseUrl ?>/uploads/products/<?= htmlspecialchars($p['image']) ?>" alt="<?= htmlspecialchars($p['name']) ?>">
                        <?php else: ?>
                            <div class="room-card-placeholder">
                                <i class="fas fa-box"></i>
                            </div>
                        <?php endif; ?>
                        <div class="room-card-price">
                            <span><?= number_format($p['price']) ?>₮</span>
                        </div>
                    </div>
                    <div class="room-card-body">
                        <?php if ($p['category_name']): ?>
                            <small style="color: var(--accent); font-weight: 600;"><?= htmlspecialchars($p['category_name']) ?></small>
                        <?php endif; ?>
                        <h3><?= htmlspecialchars($p['name']) ?></h3>
                        <?php if ($p['description']): ?>
                            <p><?= mb_substr(htmlspecialchars($p['description']), 0, 80) ?></p>
                        <?php endif; ?>
                        <?php if ($p['stock'] > 0): ?>
                            <small style="color: var(--success);"><i class="fas fa-check-circle"></i> Нөөцөд байгаа (<?= $p['stock'] ?>)</small>
                        <?php else: ?>
                            <small style="color: var(--danger);"><i class="fas fa-times-circle"></i> Дууссан</small>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section id="contact" class="section">
    <div class="container">
        <div class="section-header">
            <h2><i class="fas fa-phone-alt"></i> Холбоо барих</h2>
            <p>Бидэнтэй холбогдох</p>
        </div>
        <div class="contact-grid">
            <div class="contact-card">
                <div class="contact-icon"><i class="fas fa-phone"></i></div>
                <h3>Утасны дугаар</h3>
                <a href="tel:<?= preg_replace('/\D/', '', $contactConfig['phone']) ?>" class="contact-phone"><?= htmlspecialchars($contactConfig['phone_display'] ?? $contactConfig['phone']) ?></a>
            </div>
            <div class="contact-card contact-map-card">
                <h3><i class="fas fa-map-marker-alt"></i> Байршил</h3>
                <div class="map-wrapper">
                    <iframe src="<?= htmlspecialchars($contactConfig['google_maps_embed']) ?>" width="100%" height="300" style="border:0; border-radius: 12px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
