<?php
$pageTitle = 'Миний захиалгууд';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
requireLogin();

$base = getBaseUrl();
$userId = currentUser()['id'];

if (isset($_GET['cancel'])) {
    $bId = intval($_GET['cancel']);
    $db->prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ? AND user_id = ? AND status = 'pending'")
       ->execute([$bId, $userId]);
    header('Location: ' . $base . '/pages/my-bookings.php?cancelled=1');
    exit;
}

$bookings = $db->prepare("
    SELECT b.*, r.name as room_name, r.featured_image, r.price as room_price
    FROM bookings b
    JOIN rooms r ON b.room_id = r.id
    WHERE b.user_id = ?
    ORDER BY b.created_at DESC
");
$bookings->execute([$userId]);
$bookings = $bookings->fetchAll();

$statusLabels = [
    'pending'   => ['Хүлээгдэж буй', 'badge-pending', 'fa-clock'],
    'confirmed' => ['Баталгаажсан', 'badge-confirmed', 'fa-check-circle'],
    'completed' => ['Дууссан', 'badge-completed', 'fa-check-double'],
    'cancelled' => ['Цуцлагдсан', 'badge-cancelled', 'fa-times-circle']
];

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container">
    <div style="max-width: 900px; margin: 40px auto; padding-bottom: 40px;">
        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; margin-bottom: 24px;">
            <h1 style="font-size: 1.6rem; font-weight: 700; color: var(--text);">
                <i class="fas fa-calendar-alt" style="color: var(--primary-light);"></i> Миний захиалгууд
            </h1>
            <a href="<?= $baseUrl ?>/pages/booking.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Шинэ захиалга
            </a>
        </div>

        <?php if (isset($_GET['cancelled'])): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> Захиалга цуцлагдлаа</div>
        <?php endif; ?>

        <?php if (empty($bookings)): ?>
            <div class="empty-state">
                <i class="fas fa-calendar-times"></i>
                <h3>Танд захиалга байхгүй байна</h3>
                <p>Өрөө захиалахын тулд доорх товч дарна уу</p>
                <a href="<?= $baseUrl ?>/pages/booking.php" class="btn btn-primary">
                    <i class="fas fa-calendar-check"></i> Өрөө захиалах
                </a>
            </div>
        <?php else: ?>
            <div class="booking-list">
                <?php foreach ($bookings as $b):
                    $sl = $statusLabels[$b['status']] ?? ['?', 'badge-user', 'fa-question'];
                ?>
                <div class="booking-card">
                    <div class="booking-card-left">
                        <?php if ($b['featured_image']): ?>
                            <img src="<?= $baseUrl ?>/uploads/rooms/<?= htmlspecialchars($b['featured_image']) ?>" alt="">
                        <?php else: ?>
                            <div class="booking-card-icon"><i class="fas fa-microphone-alt"></i></div>
                        <?php endif; ?>
                    </div>
                    <div class="booking-card-body">
                        <div class="booking-card-header">
                            <h3><?= htmlspecialchars($b['room_name']) ?></h3>
                            <span class="badge <?= $sl[1] ?>"><i class="fas <?= $sl[2] ?>"></i> <?= $sl[0] ?></span>
                        </div>
                        <div class="booking-card-details">
                            <div class="booking-detail-item">
                                <i class="fas fa-calendar"></i>
                                <span><?= date('Y оны m сарын d', strtotime($b['booking_date'])) ?></span>
                            </div>
                            <div class="booking-detail-item">
                                <i class="fas fa-clock"></i>
                                <span><?= $b['start_time'] ?> - <?= $b['end_time'] ?></span>
                            </div>
                            <div class="booking-detail-item">
                                <i class="fas fa-money-bill-wave"></i>
                                <span style="font-weight: 700; color: var(--primary-light);"><?= number_format($b['total_price']) ?>₮</span>
                            </div>
                        </div>
                        <?php if ($b['note']): ?>
                            <p class="booking-note"><i class="fas fa-sticky-note"></i> <?= htmlspecialchars($b['note']) ?></p>
                        <?php endif; ?>
                        <div style="display: flex; gap: 8px; margin-top: 10px; flex-wrap: wrap;">
                            <?php if (in_array($b['status'], ['pending', 'confirmed'])): ?>
                                <a href="<?= $baseUrl ?>/pages/order.php?booking_id=<?= $b['id'] ?>"
                                   class="btn btn-sm btn-primary">
                                    <i class="fas fa-utensils"></i> Бүтээгдэхүүн захиалах
                                </a>
                                <a href="<?= $baseUrl ?>/pages/payment.php" class="btn btn-sm btn-success">
                                    <i class="fas fa-credit-card"></i> Төлбөр төлөх
                                </a>
                            <?php endif; ?>
                            <?php if ($b['status'] === 'pending'): ?>
                                <a href="<?= $baseUrl ?>/pages/my-bookings.php?cancel=<?= $b['id'] ?>"
                                   class="btn btn-sm btn-danger"
                                   onclick="return confirm('Захиалга цуцлах уу?')">
                                    <i class="fas fa-times"></i> Цуцлах
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
