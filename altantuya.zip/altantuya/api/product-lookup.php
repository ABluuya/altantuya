<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json; charset=utf-8');

if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Эрх хүрэхгүй']);
    exit;
}

$code = trim($_GET['code'] ?? '');
$search = trim($_GET['search'] ?? '');

if (!empty($code)) {
    $stmt = $db->prepare('SELECT id, code, name, price, stock FROM products WHERE code = ?');
    $stmt->execute([$code]);
    $product = $stmt->fetch();

    if ($product) {
        echo json_encode([
            'success' => true,
            'product' => $product
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Бүртгэлгүй бараа. Энэ кодтой бараа олдсонгүй.'
        ]);
    }
    exit;
}

if (!empty($search) && strlen($search) >= 1) {
    $stmt = $db->prepare("SELECT id, code, name, price, stock FROM products WHERE code LIKE ?");
    $stmt->execute(['%' . $search]);
    $products = $stmt->fetchAll();

    echo json_encode([
        'success' => true,
        'products' => $products
    ]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Код оруулна уу']);
