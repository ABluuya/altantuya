<?php
$pageTitle = 'Админ - Бараа хүлээн авах';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/database.php';
requireAdmin();

$base = getBaseUrl();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = intval($_POST['product_id'] ?? 0);
    $quantity = intval($_POST['quantity'] ?? 0);
    $note = trim($_POST['note'] ?? '');

    if (!$product_id || $quantity <= 0) {
        $error = 'Бараа болон тоо ширхэгийг зөв оруулна уу';
    } else {
        $pStmt = $db->prepare('SELECT * FROM products WHERE id = ?');
        $pStmt->execute([$product_id]);
        $product = $pStmt->fetch();

        if (!$product) {
            $error = 'Бараа олдсонгүй';
        } else {
            $unitPrice = $product['price'];
            $totalPrice = $unitPrice * $quantity;

            $db->prepare('INSERT INTO stock_receives (product_id, quantity, unit_price, total_price, note, received_by) VALUES (?, ?, ?, ?, ?, ?)')
               ->execute([$product_id, $quantity, $unitPrice, $totalPrice, $note ?: null, currentUser()['id']]);

            $db->prepare('UPDATE products SET stock = stock + ? WHERE id = ?')
               ->execute([$quantity, $product_id]);

            $success = htmlspecialchars($product['name']) . ' - ' . $quantity . ' ширхэг хүлээн авлаа. Нийт дүн: ' . number_format($totalPrice) . '₮';
        }
    }
}

$receives = $db->query("
    SELECT sr.*, p.code, p.name as product_name, u.username as received_by_name
    FROM stock_receives sr
    JOIN products p ON sr.product_id = p.id
    LEFT JOIN users u ON sr.received_by = u.id
    ORDER BY sr.created_at DESC
    LIMIT 50
")->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container">
    <div class="admin-page">
        <?php include __DIR__ . '/../../includes/admin-sidebar.php'; ?>

        <div class="admin-content">
            <h1 class="admin-title"><i class="fas fa-truck-loading"></i> Бараа хүлээн авах</h1>

            <?php if ($error): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= $error ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= $success ?></div>
            <?php endif; ?>

            <div class="form-card" style="margin-bottom: 24px;">
                <h3><i class="fas fa-barcode"></i> Барааны кодоор хайх</h3>

                <div class="form-row">
                    <div class="form-group">
                        <label>Барааны код <span class="required">*</span></label>
                        <input type="text" id="receive-code" class="form-control" placeholder="Кодыг бичнэ үү..."
                               autocomplete="off" style="font-size: 1.1rem; font-weight: 600; letter-spacing: 1px;">
                    </div>
                    <div class="form-group" style="display: flex; align-items: flex-end;">
                        <button type="button" id="receive-search-btn" class="btn btn-primary" style="width: 100%;">
                            <i class="fas fa-search"></i> Хайх
                        </button>
                    </div>
                </div>

                <div id="receive-result" style="display: none; margin-top: 16px;">
                    <div id="receive-not-found" class="alert alert-danger" style="display: none;">
                        <i class="fas fa-exclamation-triangle"></i>
                        <span>Бүртгэлгүй бараа! Энэ кодтой бараа олдсонгүй.</span>
                    </div>

                    <div id="receive-found" style="display: none;">
                        <div class="product-found-card">
                            <div class="product-found-info">
                                <div class="product-found-badge">
                                    <i class="fas fa-check-circle"></i> Бүртгэлтэй бараа
                                </div>
                                <div class="product-found-details">
                                    <div class="product-found-row">
                                        <span class="label">Код:</span>
                                        <span id="found-code" class="value code-text"></span>
                                    </div>
                                    <div class="product-found-row">
                                        <span class="label">Нэр:</span>
                                        <span id="found-name" class="value"></span>
                                    </div>
                                    <div class="product-found-row">
                                        <span class="label">Нэгж үнэ:</span>
                                        <span id="found-price" class="value price-text"></span>
                                    </div>
                                    <div class="product-found-row">
                                        <span class="label">Одоогийн үлдэгдэл:</span>
                                        <span id="found-stock" class="value"></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <form method="POST" style="margin-top: 16px;">
                            <input type="hidden" name="product_id" id="receive-product-id">
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Ирсэн тоо ширхэг <span class="required">*</span></label>
                                    <input type="number" name="quantity" id="receive-qty" class="form-control"
                                           min="1" required placeholder="Тоо ширхэгийг оруулна уу"
                                           style="font-size: 1.1rem; font-weight: 600;"
                                           oninput="calcTotal()">
                                </div>
                                <div class="form-group">
                                    <label>Нийт дүн</label>
                                    <div id="receive-total" class="receive-total-display">0₮</div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Тэмдэглэл</label>
                                <input type="text" name="note" class="form-control" placeholder="Нэмэлт тэмдэглэл...">
                            </div>
                            <button type="submit" class="btn btn-primary btn-lg" style="margin-top: 12px;">
                                <i class="fas fa-check"></i> Хүлээн авах
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="form-card" style="margin-bottom: 24px;">
                <h3><i class="fas fa-search"></i> Сүүлийн 4 оронгоор үлдэгдэл шалгах</h3>
                <div class="form-row">
                    <div class="form-group">
                        <input type="text" id="stock-search-input" class="form-control"
                               placeholder="Сүүлийн 4 оронг бичнэ үү..." maxlength="4"
                               style="font-size: 1.1rem; font-weight: 600; letter-spacing: 2px;">
                    </div>
                </div>
                <div id="stock-search-results" style="margin-top: 12px;"></div>
            </div>

            <?php if (!empty($receives)): ?>
            <div class="form-card">
                <h3><i class="fas fa-history"></i> Сүүлийн хүлээн авалтууд</h3>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Код</th>
                                <th>Бараа</th>
                                <th>Тоо</th>
                                <th>Нэгж үнэ</th>
                                <th>Нийт дүн</th>
                                <th>Хүлээн авсан</th>
                                <th>Огноо</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($receives as $r): ?>
                            <tr>
                                <td><code style="background:var(--hover);padding:2px 8px;border-radius:4px;font-weight:600;"><?= htmlspecialchars($r['code'] ?? '') ?></code></td>
                                <td><?= htmlspecialchars($r['product_name']) ?></td>
                                <td><strong><?= $r['quantity'] ?></strong></td>
                                <td><?= number_format($r['unit_price']) ?>₮</td>
                                <td><strong style="color: var(--success);"><?= number_format($r['total_price']) ?>₮</strong></td>
                                <td><?= htmlspecialchars($r['received_by_name'] ?? '-') ?></td>
                                <td><?= date('Y-m-d H:i', strtotime($r['created_at'])) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
const baseUrl = '<?= $baseUrl ?>';
let foundProduct = null;

document.getElementById('receive-search-btn').addEventListener('click', searchProduct);
document.getElementById('receive-code').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') { e.preventDefault(); searchProduct(); }
});

function searchProduct() {
    const code = document.getElementById('receive-code').value.trim();
    if (!code) return;

    fetch(baseUrl + '/api/product-lookup.php?code=' + encodeURIComponent(code))
        .then(r => r.json())
        .then(data => {
            document.getElementById('receive-result').style.display = 'block';
            if (data.success && data.product) {
                foundProduct = data.product;
                document.getElementById('receive-not-found').style.display = 'none';
                document.getElementById('receive-found').style.display = 'block';
                document.getElementById('found-code').textContent = data.product.code;
                document.getElementById('found-name').textContent = data.product.name;
                document.getElementById('found-price').textContent = Number(data.product.price).toLocaleString() + '₮';
                document.getElementById('found-stock').textContent = data.product.stock + ' ширхэг';
                document.getElementById('receive-product-id').value = data.product.id;
                document.getElementById('receive-qty').value = '';
                document.getElementById('receive-total').textContent = '0₮';
                document.getElementById('receive-qty').focus();
            } else {
                foundProduct = null;
                document.getElementById('receive-not-found').style.display = 'flex';
                document.getElementById('receive-found').style.display = 'none';
            }
        });
}

function calcTotal() {
    if (!foundProduct) return;
    const qty = parseInt(document.getElementById('receive-qty').value) || 0;
    const total = qty * foundProduct.price;
    document.getElementById('receive-total').textContent = total.toLocaleString() + '₮';
}

let searchTimeout;
document.getElementById('stock-search-input').addEventListener('input', function() {
    clearTimeout(searchTimeout);
    const val = this.value.trim();
    const container = document.getElementById('stock-search-results');

    if (val.length === 0) { container.innerHTML = ''; return; }

    searchTimeout = setTimeout(() => {
        fetch(baseUrl + '/api/product-lookup.php?search=' + encodeURIComponent(val))
            .then(r => r.json())
            .then(data => {
                if (data.success && data.products && data.products.length > 0) {
                    let html = '<div class="table-responsive"><table class="data-table"><thead><tr><th>Код</th><th>Нэр</th><th>Үнэ</th><th>Үлдэгдэл</th></tr></thead><tbody>';
                    data.products.forEach(p => {
                        const stockClass = p.stock > 0 ? 'color:var(--success)' : 'color:var(--danger)';
                        html += '<tr>'
                            + '<td><code style="background:var(--hover);padding:2px 8px;border-radius:4px;font-weight:600;">' + p.code + '</code></td>'
                            + '<td>' + p.name + '</td>'
                            + '<td>' + Number(p.price).toLocaleString() + '₮</td>'
                            + '<td><strong style="' + stockClass + '">' + p.stock + ' ширхэг</strong></td>'
                            + '</tr>';
                    });
                    html += '</tbody></table></div>';
                    container.innerHTML = html;
                } else {
                    container.innerHTML = '<div class="alert alert-danger"><i class="fas fa-times-circle"></i> Олдсонгүй</div>';
                }
            });
    }, 300);
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
