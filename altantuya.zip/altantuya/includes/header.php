<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';

$baseUrl = '';
if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/altantuya')) {
    $baseUrl = '/altantuya';
}
?>
<!DOCTYPE html>
<html lang="mn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'Караоке' ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>/assets/css/style.css">
    <script>
        (function() {
            var t = localStorage.getItem('theme');
            if (t === 'dark') document.documentElement.classList.add('dark-theme-preload');
        })();
    </script>
    <style>
        html.dark-theme-preload body,
        html.dark-theme-preload { background: #0B0F19; color: #F9FAFB; }
        html.dark-theme-preload .navbar { background: #111827; border-color: #374151; }
        html.dark-theme-preload .footer { background: #1A1A2E; border-color: #374151; }
        html.dark-theme-preload .theme-icon-light { opacity: 0; }
        html.dark-theme-preload .theme-icon-dark { opacity: 1; transform: rotate(0deg); }
    </style>
</head>
<body>
    <script>
        if (localStorage.getItem('theme') === 'dark') {
            document.body.classList.add('dark-theme');
        }
        document.documentElement.classList.remove('dark-theme-preload');
    </script>

    <header class="navbar">
        <div class="container nav-container">
            <a href="<?= $baseUrl ?>/" class="logo">
                <i class="fas fa-microphone-alt"></i>
                <span>Алтантуяа Караоке</span>
            </a>

            <span class="navigation_group">
                <a href="<?= $baseUrl ?>/" class="nav-link">
                    <i class="fas fa-home"></i> Нүүр
                </a>
                <a href="<?= $baseUrl ?>/#rooms" class="nav-link">
                    <i class="fas fa-door-open"></i> Өрөө
                </a>
                <a href="<?= $baseUrl ?>/#menu" class="nav-link">
                    <i class="fas fa-utensils"></i> Бүтээгдэхүүн
                </a>
                <a href="<?= $baseUrl ?>/#contact" class="nav-link">
                    <i class="fas fa-phone-alt"></i> Холбоо барих
                </a>

                <?php if (isLoggedIn() && isAdmin()): ?>
                    <a href="<?= $baseUrl ?>/pages/admin/dashboard.php" class="nav-link">
                        <i class="fas fa-tachometer-alt"></i> Админ
                    </a>
                <?php endif; ?>

                <?php if (isLoggedIn()): ?>
                    <button
                        class="profile-trigger"
                        id="profile-menu-btn"
                        aria-haspopup="true"
                        aria-expanded="false"
                    >
                        <div class="profile-avatar">
                            <?= strtoupper(mb_substr($_SESSION['user']['username'], 0, 1)) ?>
                        </div>
                    </button>
                <?php else: ?>
                    <a href="<?= $baseUrl ?>/pages/login.php" class="nav-link">
                        <i class="fas fa-sign-in-alt"></i> Нэвтрэх
                    </a>
                    <a href="<?= $baseUrl ?>/pages/register.php" class="btn btn-primary btn-sm">Бүртгүүлэх</a>
                <?php endif; ?>

                <button class="theme-btn" id="theme-btn-nav" title="Горим солих">
                    <i class="fas fa-sun theme-icon-light"></i>
                    <i class="fas fa-moon theme-icon-dark"></i>
                </button>
            </span>

            <?php if (isLoggedIn()): ?>
            <div class="dropdown_wrapper" id="profile-dropdown">
                <nav>
                    <ul>
                        <li>
                            <a href="<?= $baseUrl ?>/">
                                <i class="fas fa-home"></i> Нүүр хуудас
                            </a>
                        </li>
                        <li>
                            <a href="<?= $baseUrl ?>/pages/booking.php">
                                <i class="fas fa-calendar-check"></i> Өрөө захиалах
                            </a>
                        </li>
                        <li>
                            <a href="<?= $baseUrl ?>/pages/my-bookings.php">
                                <i class="fas fa-list-alt"></i> Миний захиалгууд
                            </a>
                        </li>
                        <li>
                            <a href="<?= $baseUrl ?>/pages/order.php">
                                <i class="fas fa-utensils"></i> Бүтээгдэхүүн захиалах
                            </a>
                        </li>
                        <li>
                            <a href="<?= $baseUrl ?>/pages/payment.php">
                                <i class="fas fa-credit-card"></i> Төлбөр төлөх
                            </a>
                        </li>
                        <?php if (isAdmin()): ?>
                        <li>
                            <a href="<?= $baseUrl ?>/pages/admin/dashboard.php">
                                <i class="fas fa-tachometer-alt"></i> Хянах самбар
                            </a>
                        </li>
                        <li>
                            <a href="<?= $baseUrl ?>/pages/admin/rooms.php">
                                <i class="fas fa-door-open"></i> Өрөөнүүд
                            </a>
                        </li>
                        <li>
                            <a href="<?= $baseUrl ?>/pages/admin/users.php">
                                <i class="fas fa-users"></i> Хэрэглэгчид
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>

                    <hr class="divider">

                    <ul>
                        <li class="toggle-item">
                            <div class="flex-row">
                                <i class="fas fa-moon"></i>
                                <span>Шөнийн горим</span>
                            </div>
                            <label class="switch">
                                <input type="checkbox" id="theme-toggle">
                                <span class="slider round"></span>
                            </label>
                        </li>
                    </ul>

                    <hr class="divider">

                    <div class="switch_account">
                        <h2>Хэрэглэгчийн мэдээлэл</h2>
                        <ul>
                            <li class="active">
                                <div class="role-icon <?= isAdmin() ? 'admin-icon' : 'user-icon' ?>">
                                    <i class="fas <?= isAdmin() ? 'fa-crown' : 'fa-user' ?>"></i>
                                </div>
                                <div class="user-info">
                                    <div class="name"><?= htmlspecialchars($_SESSION['user']['username']) ?></div>
                                    <div class="email">
                                        <?= isAdmin() ? 'Админ эрхтэй' : 'Хэрэглэгч' ?>
                                    </div>
                                </div>
                                <div class="marker"></div>
                            </li>
                        </ul>
                    </div>

                    <hr class="divider">

                    <a href="<?= $baseUrl ?>/pages/logout.php">
                        <button class="sign-out-all">
                            <i class="fas fa-sign-out-alt"></i>
                            Гарах
                        </button>
                    </a>
                </nav>
            </div>
            <?php endif; ?>

            <button class="mobile-toggle" onclick="document.querySelector('.navigation_group').classList.toggle('active')">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </header>
    <main class="main-content">
