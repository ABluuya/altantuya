<?php
$pageTitle = 'Админ - Хэрэглэгчид';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/database.php';
requireAdmin();

$base = getBaseUrl();

if (isset($_GET['delete']) && intval($_GET['delete']) !== currentUser()['id']) {
    $db->prepare('DELETE FROM users WHERE id = ? AND role != ?')->execute([intval($_GET['delete']), 'admin']);
    header('Location: ' . $base . '/pages/admin/users.php?deleted=1');
    exit;
}

$users = $db->query("
    SELECT u.*,
           (SELECT COUNT(*) FROM bookings WHERE user_id = u.id) as booking_count,
           (SELECT COUNT(*) FROM orders WHERE user_id = u.id) as order_count
    FROM users u ORDER BY u.created_at DESC
")->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container">
    <div class="admin-page">
        <?php include __DIR__ . '/../../includes/admin-sidebar.php'; ?>

        <div class="admin-content">
            <h1 class="admin-title"><i class="fas fa-users"></i> Хэрэглэгчдийн жагсаалт</h1>

            <?php if (isset($_GET['deleted'])): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> Хэрэглэгч устгагдлаа</div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Хэрэглэгч</th>
                            <th>Холбоо барих</th>
                            <th>Эрх</th>
                            <th>Захиалга</th>
                            <th>Бүртгүүлсэн</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $i => $u): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td>
                                <strong><?= htmlspecialchars($u['username']) ?></strong>
                                <?php if ($u['fullname']): ?>
                                    <br><small style="color:var(--text-muted)"><?= htmlspecialchars($u['fullname']) ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($u['phone']): ?>
                                    <small><i class="fas fa-phone" style="color:var(--primary-light);font-size:0.7rem;"></i> <?= htmlspecialchars($u['phone']) ?></small>
                                <?php endif; ?>
                                <?php if ($u['email']): ?>
                                    <br><small><i class="fas fa-envelope" style="color:var(--primary-light);font-size:0.7rem;"></i> <?= htmlspecialchars($u['email']) ?></small>
                                <?php endif; ?>
                                <?php if (!$u['phone'] && !$u['email']): ?>-<?php endif; ?>
                            </td>
                            <td>
                                <span class="badge badge-<?= $u['role'] === 'admin' ? 'admin' : 'user' ?>">
                                    <?= $u['role'] === 'admin' ? 'Админ' : 'Хэрэглэгч' ?>
                                </span>
                            </td>
                            <td style="text-align:center;">
                                <span class="badge badge-user"><?= $u['booking_count'] ?></span>
                            </td>
                            <td><?= date('m/d H:i', strtotime($u['created_at'])) ?></td>
                            <td>
                                <?php if ($u['role'] !== 'admin'): ?>
                                    <a href="<?= $baseUrl ?>/pages/admin/users.php?delete=<?= $u['id'] ?>"
                                       class="btn btn-sm btn-danger" onclick="return confirm('Хэрэглэгч устгах уу?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
