<?php
/**
 * Тохиргоо унших/бичих
 * DB-аас уншиж, байхгүй бол config файлаас авна
 */
function getSetting($key, $default = '') {
    global $db;
    if (!isset($db)) return $default;
    try {
        $stmt = $db->prepare('SELECT setting_value FROM settings WHERE setting_key = ?');
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        return $row ? $row['setting_value'] : $default;
    } catch (Exception $e) {
        return $default;
    }
}

function setSetting($key, $value) {
    global $db;
    $stmt = $db->prepare('INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)');
    return $stmt->execute([$key, $value]);
}

function getContactConfig() {
    $default = require __DIR__ . '/contact.php';
    global $db;
    if (!isset($db)) return $default;
    return [
        'phone' => getSetting('contact_phone', $default['phone']),
        'phone_display' => getSetting('contact_phone_display', $default['phone_display']),
        'google_maps_embed' => getSetting('contact_google_maps', $default['google_maps_embed']),
    ];
}

function getPaymentConfig() {
    $default = require __DIR__ . '/payment.php';
    global $db;
    if (!isset($db)) return $default;
    return [
        'bank_name' => getSetting('payment_bank_name', $default['bank_name']),
        'account_name' => getSetting('payment_account_name', $default['account_name']),
        'account_number' => getSetting('payment_account_number', $default['account_number']),
        'bank_code' => getSetting('payment_bank_code', $default['bank_code']),
        'qr_image' => getSetting('payment_qr_image', $default['qr_image'] ?? ''),
    ];
}
