<?php
$pageTitle = 'Админ - Бараа бүтээгдэхүүн';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/database.php';
requireAdmin();

$base = getBaseUrl();

if (isset($_GET['delete'])) {
    $deleteId = intval($_GET['delete']);
    $prod = $db->prepare('SELECT image FROM products WHERE id = ?');
    $prod->execute([$deleteId]);
    $prodData = $prod->fetch();
    if ($prodData && $prodData['image']) {
        $imgPath = __DIR__ . '/../../uploads/products/' . $prodData['image'];
        if (file_exists($imgPath)) unlink($imgPath);
    }
    $db->prepare('DELETE FROM products WHERE id = ?')->execute([$deleteId]);
    header('Location: ' . $base . '/pages/admin/products.php?deleted=1');
    exit;
}

$catFilter = $_GET['category'] ?? '';
$query = "SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id";
$params = [];
if ($catFilter) {
    $query .= " WHERE p.category_id = ?";
    $params[] = intval($catFilter);
}
$query .= " ORDER BY p.created_at DESC";
$stmt = $db->prepare($query);
$stmt->execute($params);
$products = $stmt->fetchAll();

$categories = $db->query('SELECT * FROM categories ORDER BY name')->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container">
    <div class="admin-page">
        <?php include __DIR__ . '/../../includes/admin-sidebar.php'; ?>

        <div class="admin-content">
            <div class="admin-content-header">
                <h1 class="admin-title"><i class="fas fa-box"></i> Бараа бүтээгдэхүүн</h1>
                <a href="<?= $baseUrl ?>/pages/admin/product-create.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Шинэ бараа нэмэх
                </a>
            </div>

            <?php if (isset($_GET['deleted'])): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> Бараа устгагдлаа</div>
            <?php endif; ?>
            <?php if (isset($_GET['created'])): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> Бараа амжилттай нэмэгдлээ</div>
            <?php endif; ?>
            <?php if (isset($_GET['updated'])): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> Бараа шинэчлэгдлээ</div>
            <?php endif; ?>

            <?php if (!empty($categories)): ?>
            <div style="margin-bottom: 20px; display: flex; gap: 8px; flex-wrap: wrap;">
                <a href="<?= $baseUrl ?>/pages/admin/products.php" class="btn btn-sm <?= !$catFilter ? 'btn-primary' : 'btn-outline' ?>">Бүгд</a>
                <?php foreach ($categories as $cat): ?>
                    <a href="<?= $baseUrl ?>/pages/admin/products.php?category=<?= $cat['id'] ?>"
                       class="btn btn-sm <?= $catFilter == $cat['id'] ? 'btn-primary' : 'btn-outline' ?>">
                        <?= htmlspecialchars($cat['name']) ?>
                    </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if (empty($products)): ?>
                <div class="empty-state">
                    <i class="fas fa-box-open"></i>
                    <h3>Бараа бүртгэгдээгүй байна</h3>
                    <a href="<?= $baseUrl ?>/pages/admin/product-create.php" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Эхний бараагаа нэмэх
                    </a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Код / Нэр</th>
                                <th>Ангилал</th>
                                <th>Үнэ</th>
                                <th>Нөөц</th>
                                <th>Төлөв</th>
                                <th>Үйлдэл</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $p): ?>
                            <tr>
                                <td style="width:50px;">
                                    <?php if ($p['image']): ?>
                                        <img src="<?= $baseUrl ?>/uploads/products/<?= htmlspecialchars($p['image']) ?>" class="table-thumb" alt="">
                                    <?php else: ?>
                                        <div class="table-thumb-placeholder"><i class="fas fa-image"></i></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <code style="background:var(--hover);padding:1px 6px;border-radius:4px;font-weight:600;font-size:0.75rem;"><?= htmlspecialchars($p['code'] ?? '-') ?></code>
                                    <br><strong><?= htmlspecialchars($p['name']) ?></strong>
                                </td>
                                <td><small><?= htmlspecialchars($p['category_name'] ?? '-') ?></small></td>
                                <td><?= number_format($p['price']) ?>₮</td>
                                <td style="text-align:center;"><?= $p['stock'] ?></td>
                                <td>
                                    <span class="badge badge-<?= $p['status'] === 'active' ? 'user' : 'admin' ?>">
                                        <?= $p['status'] === 'active' ? 'Идэвхтэй' : 'Идэвхгүй' ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="<?= $baseUrl ?>/pages/admin/product-edit.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline"><i class="fas fa-edit"></i></a>
                                        <a href="<?= $baseUrl ?>/pages/admin/products.php?delete=<?= $p['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Устгах уу?')"><i class="fas fa-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
