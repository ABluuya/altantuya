<?php
$pageTitle = 'Бүтээгдэхүүн захиалах';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
requireLogin();

$base = getBaseUrl();
$userId = currentUser()['id'];
$bookingId = intval($_GET['booking_id'] ?? 0);

$booking = null;
if ($bookingId) {
    $stmt = $db->prepare("SELECT b.*, r.name as room_name FROM bookings b JOIN rooms r ON b.room_id = r.id WHERE b.id = ? AND b.user_id = ? AND b.status IN ('pending','confirmed')");
    $stmt->execute([$bookingId, $userId]);
    $booking = $stmt->fetch();
}

if (!$booking) {
    $activeBookings = $db->prepare("SELECT b.*, r.name as room_name FROM bookings b JOIN rooms r ON b.room_id = r.id WHERE b.user_id = ? AND b.status IN ('pending','confirmed') ORDER BY b.booking_date DESC");
    $activeBookings->execute([$userId]);
    $activeBookings = $activeBookings->fetchAll();
}

$categories = $db->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$products = $db->query("SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.status = 'active' AND p.stock > 0 ORDER BY c.name, p.name")->fetchAll();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $booking) {
    $items = $_POST['qty'] ?? [];
    $orderItems = [];
    $totalPrice = 0;

    foreach ($items as $productId => $qty) {
        $qty = intval($qty);
        if ($qty <= 0) continue;

        $pStmt = $db->prepare('SELECT * FROM products WHERE id = ? AND status = ? AND stock >= ?');
        $pStmt->execute([intval($productId), 'active', $qty]);
        $product = $pStmt->fetch();

        if ($product) {
            $orderItems[] = [
                'product_id' => $product['id'],
                'quantity' => $qty,
                'price' => $product['price'],
                'name' => $product['name']
            ];
            $totalPrice += $product['price'] * $qty;
        }
    }

    if (empty($orderItems)) {
        $error = 'Хамгийн багадаа 1 бүтээгдэхүүн сонгоно уу';
    } else {
        $db->prepare('INSERT INTO orders (booking_id, user_id, total_price, status) VALUES (?, ?, ?, ?)')
           ->execute([$booking['id'], $userId, $totalPrice, 'pending']);
        $orderId = $db->lastInsertId();

        foreach ($orderItems as $item) {
            $db->prepare('INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)')
               ->execute([$orderId, $item['product_id'], $item['quantity'], $item['price']]);
            $db->prepare('UPDATE products SET stock = stock - ? WHERE id = ?')
               ->execute([$item['quantity'], $item['product_id']]);
        }

        header('Location: payment.php?booking_id=' . $booking['id'] . '&order_success=1');
        exit;
    }
}

$existingOrders = [];
if ($booking) {
    $oStmt = $db->prepare("
        SELECT o.*,
               (SELECT GROUP_CONCAT(CONCAT(p.name, ' x', oi.quantity) SEPARATOR ', ')
                FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = o.id) as items_summary
        FROM orders o WHERE o.booking_id = ? AND o.user_id = ? ORDER BY o.created_at DESC
    ");
    $oStmt->execute([$booking['id'], $userId]);
    $existingOrders = $oStmt->fetchAll();
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container">
    <div style="max-width: 900px; margin: 40px auto; padding-bottom: 40px;">
        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; margin-bottom: 20px;">
            <a href="<?= $baseUrl ?>/pages/my-bookings.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Миний захиалгууд</a>
        </div>

        <?php if (!$booking): ?>
            <div class="form-card">
                <h3><i class="fas fa-door-open"></i> Өрөө сонгоно уу</h3>
                <?php if (empty($activeBookings)): ?>
                    <div class="empty-state" style="padding: 30px;">
                        <i class="fas fa-calendar-times"></i>
                        <h3>Идэвхтэй захиалга байхгүй байна</h3>
                        <p>Бүтээгдэхүүн захиалахын тулд эхлээд өрөө захиална уу</p>
                        <a href="<?= $baseUrl ?>/pages/booking.php" class="btn btn-primary">
                            <i class="fas fa-calendar-check"></i> Өрөө захиалах
                        </a>
                    </div>
                <?php else: ?>
                    <p style="color: var(--text-muted); margin-bottom: 16px;">Аль захиалга руу бүтээгдэхүүн нэмэх вэ?</p>
                    <div class="booking-list">
                        <?php foreach ($activeBookings as $ab): ?>
                        <a href="<?= $baseUrl ?>/pages/order.php?booking_id=<?= $ab['id'] ?>" class="booking-card" style="text-decoration: none; cursor: pointer;">
                            <div class="booking-card-left" style="width: 80px; min-height: 80px;">
                                <div class="booking-card-icon"><i class="fas fa-door-open"></i></div>
                            </div>
                            <div class="booking-card-body">
                                <h3 style="color: var(--text); font-size: 1rem;"><?= htmlspecialchars($ab['room_name']) ?></h3>
                                <div class="booking-card-details">
                                    <div class="booking-detail-item"><i class="fas fa-calendar"></i> <?= $ab['booking_date'] ?></div>
                                    <div class="booking-detail-item"><i class="fas fa-clock"></i> <?= $ab['start_time'] ?> - <?= $ab['end_time'] ?></div>
                                </div>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php else: ?>

            <div class="product-found-card" style="margin-bottom: 24px;">
                <div class="product-found-badge">
                    <i class="fas fa-door-open"></i> <?= htmlspecialchars($booking['room_name']) ?>
                </div>
                <div class="booking-card-details">
                    <div class="booking-detail-item"><i class="fas fa-calendar"></i> <?= $booking['booking_date'] ?></div>
                    <div class="booking-detail-item"><i class="fas fa-clock"></i> <?= $booking['start_time'] ?> - <?= $booking['end_time'] ?></div>
                </div>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= $error ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= $success ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-card" style="margin-bottom: 24px;">
                    <h3><i class="fas fa-utensils"></i> Бүтээгдэхүүн сонгох</h3>

                    <?php if (empty($products)): ?>
                        <div class="empty-state" style="padding: 20px;">
                            <i class="fas fa-box-open"></i>
                            <h3>Бүтээгдэхүүн байхгүй байна</h3>
                        </div>
                    <?php else: ?>
                        <div class="order-products-grid">
                            <?php
                            $currentCat = null;
                            foreach ($products as $p):
                                if ($p['category_name'] !== $currentCat):
                                    $currentCat = $p['category_name'];
                            ?>
                                <div class="order-cat-header"><?= htmlspecialchars($currentCat ?? 'Бусад') ?></div>
                            <?php endif; ?>
                            <div class="order-product-row">
                                <div class="order-product-info">
                                    <?php if ($p['image']): ?>
                                        <img src="<?= $baseUrl ?>/uploads/products/<?= htmlspecialchars($p['image']) ?>" class="order-product-img" alt="">
                                    <?php else: ?>
                                        <div class="order-product-img-placeholder"><i class="fas fa-box"></i></div>
                                    <?php endif; ?>
                                    <div>
                                        <div class="order-product-name"><?= htmlspecialchars($p['name']) ?></div>
                                        <div class="order-product-price"><?= number_format($p['price']) ?>₮</div>
                                        <div class="order-product-stock">Үлдэгдэл: <?= $p['stock'] ?></div>
                                    </div>
                                </div>
                                <div class="order-product-qty">
                                    <button type="button" class="qty-btn" onclick="changeQty(this, -1, <?= $p['price'] ?>, <?= $p['stock'] ?>)">-</button>
                                    <input type="number" name="qty[<?= $p['id'] ?>]" value="0" min="0" max="<?= $p['stock'] ?>"
                                           class="qty-input" data-price="<?= $p['price'] ?>"
                                           onchange="recalcTotal()">
                                    <button type="button" class="qty-btn" onclick="changeQty(this, 1, <?= $p['price'] ?>, <?= $p['stock'] ?>)">+</button>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="form-card" style="margin-bottom: 24px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
                        <div>
                            <div style="color: var(--text-muted); font-size: 0.9rem;">Сонгосон бүтээгдэхүүн:</div>
                            <div id="order-item-count" style="font-weight: 700; font-size: 1.1rem; color: var(--text);">0 төрөл</div>
                        </div>
                        <div style="text-align: right;">
                            <div style="color: var(--text-muted); font-size: 0.9rem;">Нийт дүн:</div>
                            <div id="order-total" style="font-weight: 800; font-size: 1.5rem; color: var(--success);">0₮</div>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-lg btn-block" id="order-submit-btn" disabled>
                    <i class="fas fa-paper-plane"></i> Захиалга илгээх
                </button>
            </form>

            <?php if (!empty($existingOrders)): ?>
            <div class="form-card" style="margin-top: 24px;">
                <h3><i class="fas fa-history"></i> Энэ өрөөнд хийсэн захиалгууд</h3>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead><tr><th>#</th><th>Бүтээгдэхүүнүүд</th><th>Нийт дүн</th><th>Төлөв</th><th>Огноо</th></tr></thead>
                        <tbody>
                            <?php foreach ($existingOrders as $i => $o):
                                $osl = ['pending'=>'Хүлээгдэж буй','completed'=>'Дууссан','cancelled'=>'Цуцлагдсан'];
                                $oslBadge = ['pending'=>'badge-pending','completed'=>'badge-completed','cancelled'=>'badge-cancelled'];
                            ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td><small><?= htmlspecialchars($o['items_summary'] ?? '-') ?></small></td>
                                <td><strong><?= number_format($o['total_price']) ?>₮</strong></td>
                                <td><span class="badge <?= $oslBadge[$o['status']] ?? 'badge-user' ?>"><?= $osl[$o['status']] ?? $o['status'] ?></span></td>
                                <td><?= date('m/d H:i', strtotime($o['created_at'])) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

        <?php endif; ?>
    </div>
</div>

<script>
function changeQty(btn, delta, price, maxStock) {
    const input = btn.parentElement.querySelector('.qty-input');
    let val = parseInt(input.value) || 0;
    val += delta;
    if (val < 0) val = 0;
    if (val > maxStock) val = maxStock;
    input.value = val;
    recalcTotal();
}

function recalcTotal() {
    const inputs = document.querySelectorAll('.qty-input');
    let total = 0, count = 0;
    inputs.forEach(inp => {
        const qty = parseInt(inp.value) || 0;
        const price = parseInt(inp.dataset.price) || 0;
        if (qty > 0) { total += qty * price; count++; }
    });
    document.getElementById('order-total').textContent = total.toLocaleString() + '₮';
    document.getElementById('order-item-count').textContent = count + ' төрөл';
    document.getElementById('order-submit-btn').disabled = (count === 0);
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
