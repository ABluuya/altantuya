<?php
require_once __DIR__ . '/../config/auth.php';
$base = getBaseUrl();
session_destroy();
header('Location: ' . $base . '/');
exit;
