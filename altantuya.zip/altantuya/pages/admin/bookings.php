<?php
$pageTitle = 'Админ - Захиалга';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/database.php';
requireAdmin();

$base = getBaseUrl();

if (isset($_GET['status_update'])) {
    $bId = intval($_GET['status_update']);
    $newStatus = $_GET['to'] ?? '';
    $validStatuses = ['pending', 'confirmed', 'completed', 'cancelled'];
    if ($bId && in_array($newStatus, $validStatuses)) {
        if ($newStatus === 'completed') {
            $b = $db->prepare("SELECT total_price FROM bookings WHERE id = ?");
            $b->execute([$bId]);
            $bk = $b->fetch();
            $productTotal = $db->prepare("SELECT COALESCE(SUM(total_price), 0) as t FROM orders WHERE booking_id = ? AND status != 'cancelled'");
            $productTotal->execute([$bId]);
            $grandTotal = (int) $bk['total_price'] + (int) $productTotal->fetch()['t'];
            $paidSum = $db->prepare("SELECT COALESCE(SUM(amount), 0) as t FROM payments WHERE booking_id = ? AND status = 'paid'");
            $paidSum->execute([$bId]);
            $totalPaid = (int) $paidSum->fetch()['t'];
            if ($totalPaid < $grandTotal) {
                header('Location: ' . $base . '/pages/admin/bookings.php?balance_error=1&id=' . $bId);
                exit;
            }
        }
        $db->prepare('UPDATE bookings SET status = ? WHERE id = ?')->execute([$newStatus, $bId]);
        if ($newStatus === 'completed') {
            $db->prepare("UPDATE orders SET status = 'completed' WHERE booking_id = ? AND status = 'pending'")->execute([$bId]);
            $db->prepare("UPDATE payments SET status = 'paid' WHERE booking_id = ? AND status = 'pending'")->execute([$bId]);
        }
    }
    header('Location: ' . $base . '/pages/admin/bookings.php');
    exit;
}

if (isset($_GET['archive'])) {
    $db->prepare('UPDATE bookings SET archived = 1 WHERE id = ?')->execute([intval($_GET['archive'])]);
    header('Location: ' . $base . '/pages/admin/bookings.php?archived_ok=1');
    exit;
}

if (isset($_GET['archive_selected']) && !empty($_POST['ids'])) {
    $ids = array_map('intval', $_POST['ids']);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $db->prepare("UPDATE bookings SET archived = 1 WHERE id IN ($placeholders)")->execute($ids);
    header('Location: ' . $base . '/pages/admin/bookings.php?archived_ok=1');
    exit;
}

$statusFilter = $_GET['filter'] ?? '';
$query = "SELECT b.*, u.username, u.fullname, u.phone as user_phone, r.name as room_name,
                 COALESCE((SELECT SUM(o.total_price) FROM orders o WHERE o.booking_id = b.id AND o.status != 'cancelled'), 0) as product_total
           FROM bookings b
           JOIN users u ON b.user_id = u.id
           JOIN rooms r ON b.room_id = r.id
           WHERE b.archived = 0";
$params = [];
if ($statusFilter) {
    $query .= " AND b.status = ?";
    $params[] = $statusFilter;
}
$query .= " ORDER BY b.created_at DESC";
$stmt = $db->prepare($query);
$stmt->execute($params);
$bookings = $stmt->fetchAll();

$statusLabels = [
    'pending' => ['Хүлээгдэж буй', 'badge-pending'],
    'confirmed' => ['Баталгаажсан', 'badge-confirmed'],
    'completed' => ['Дууссан', 'badge-completed'],
    'cancelled' => ['Цуцлагдсан', 'badge-cancelled']
];

$archivedCount = $db->query("SELECT COUNT(*) as cnt FROM bookings WHERE archived = 1")->fetch()['cnt'];

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container">
    <div class="admin-page">
        <?php include __DIR__ . '/../../includes/admin-sidebar.php'; ?>

        <div class="admin-content">
            <div class="admin-content-header">
                <h1 class="admin-title"><i class="fas fa-calendar-check"></i> Захиалга</h1>
                <?php if ($archivedCount > 0): ?>
                <a href="<?= $baseUrl ?>/pages/admin/bookings-archive.php" class="btn btn-outline">
                    <i class="fas fa-archive"></i> Архив (<?= $archivedCount ?>)
                </a>
                <?php endif; ?>
            </div>

            <?php if (isset($_GET['archived_ok'])): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> Захиалга архивлагдлаа</div>
            <?php endif; ?>
            <?php if (isset($_GET['balance_error'])): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> Төлбөрийн үлдэгдэл төлөгдөөгүй тул дуусгах боломжгүй.
                    <a href="<?= $baseUrl ?>/pages/admin/booking-detail.php?id=<?= intval($_GET['id'] ?? 0) ?>" style="margin-left:8px;">Тооцоо харах →</a>
                </div>
            <?php endif; ?>

            <div style="margin-bottom: 20px; display: flex; gap: 8px; flex-wrap: wrap;">
                <a href="<?= $baseUrl ?>/pages/admin/bookings.php" class="btn btn-sm <?= !$statusFilter ? 'btn-primary' : 'btn-outline' ?>">Бүгд</a>
                <?php foreach ($statusLabels as $key => $val): ?>
                    <a href="<?= $baseUrl ?>/pages/admin/bookings.php?filter=<?= $key ?>"
                       class="btn btn-sm <?= $statusFilter === $key ? 'btn-primary' : 'btn-outline' ?>"><?= $val[0] ?></a>
                <?php endforeach; ?>
            </div>

            <?php if (empty($bookings)): ?>
                <div class="empty-state">
                    <i class="fas fa-calendar-times"></i>
                    <h3>Захиалга байхгүй байна</h3>
                </div>
            <?php else: ?>
                <form method="POST" action="<?= $baseUrl ?>/pages/admin/bookings.php?archive_selected=1">
                <div style="margin-bottom: 12px; display: flex; gap: 8px; align-items: center;">
                    <label style="display: flex; align-items: center; gap: 6px; cursor: pointer; color: var(--text-muted); font-size: 0.85rem;">
                        <input type="checkbox" id="select-all" onclick="toggleAll(this)"> Бүгдийг сонгох
                    </label>
                    <button type="submit" class="btn btn-sm btn-outline" id="bulk-archive-btn" style="display: none;"
                            onclick="return confirm('Сонгосон захиалгуудыг архивлах уу?')">
                        <i class="fas fa-archive"></i> Сонгосон архивлах
                    </button>
                </div>

                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width:28px;"></th>
                                <th>Хэрэглэгч</th>
                                <th>Өрөө</th>
                                <th>Огноо / Цаг</th>
                                <th>Дүн</th>
                                <th>Төлөв</th>
                                <th>Үйлдэл</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bookings as $i => $b):
                                $grandTotal = $b['total_price'] + $b['product_total'];
                            ?>
                            <tr>
                                <td><input type="checkbox" name="ids[]" value="<?= $b['id'] ?>" class="row-check" onchange="updateBulk()"></td>
                                <td>
                                    <strong><?= htmlspecialchars($b['fullname'] ?? $b['username']) ?></strong>
                                    <?php if ($b['user_phone']): ?>
                                        <br><small style="color:var(--text-muted)"><?= htmlspecialchars($b['user_phone']) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($b['room_name']) ?></td>
                                <td>
                                    <?= date('m/d', strtotime($b['booking_date'])) ?>
                                    <br><small style="color:var(--text-muted)"><?= $b['start_time'] ?>-<?= $b['end_time'] ?></small>
                                </td>
                                <td>
                                    <strong style="color: var(--success);"><?= number_format($grandTotal) ?>₮</strong>
                                    <?php if ($b['product_total'] > 0): ?>
                                        <br><small style="color:var(--text-muted)">Өрөө <?= number_format($b['total_price']) ?>₮ + Бараа <?= number_format($b['product_total']) ?>₮</small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php $sl = $statusLabels[$b['status']] ?? ['?', 'badge-user']; ?>
                                    <span class="badge <?= $sl[1] ?>"><?= $sl[0] ?></span>
                                </td>
                                <td>
                                    <div class="action-buttons" style="flex-wrap: wrap;">
                                        <a href="<?= $baseUrl ?>/pages/admin/booking-detail.php?id=<?= $b['id'] ?>"
                                           class="btn btn-sm btn-outline" title="Тооцоо харах"><i class="fas fa-receipt"></i></a>
                                        <?php if ($b['status'] === 'pending'): ?>
                                            <a href="<?= $baseUrl ?>/pages/admin/bookings.php?status_update=<?= $b['id'] ?>&to=confirmed" class="btn btn-sm btn-primary" title="Батлах"><i class="fas fa-check"></i></a>
                                        <?php endif; ?>
                                        <?php if ($b['status'] === 'confirmed'): ?>
                                            <a href="<?= $baseUrl ?>/pages/admin/bookings.php?status_update=<?= $b['id'] ?>&to=completed" class="btn btn-sm btn-primary" title="Дуусгах"><i class="fas fa-check-double"></i></a>
                                        <?php endif; ?>
                                        <?php if (in_array($b['status'], ['pending', 'confirmed'])): ?>
                                            <a href="<?= $baseUrl ?>/pages/admin/bookings.php?status_update=<?= $b['id'] ?>&to=cancelled" class="btn btn-sm btn-outline" title="Цуцлах"><i class="fas fa-ban"></i></a>
                                        <?php endif; ?>
                                        <a href="<?= $baseUrl ?>/pages/admin/bookings.php?archive=<?= $b['id'] ?>"
                                           class="btn btn-sm btn-danger" title="Архивлах"
                                           onclick="return confirm('Архивлах уу?')">
                                            <i class="fas fa-archive"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function toggleAll(master) {
    document.querySelectorAll('.row-check').forEach(c => c.checked = master.checked);
    updateBulk();
}
function updateBulk() {
    const checked = document.querySelectorAll('.row-check:checked').length;
    document.getElementById('bulk-archive-btn').style.display = checked > 0 ? 'inline-flex' : 'none';
}
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
