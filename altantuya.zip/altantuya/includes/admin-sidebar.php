<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<div class="admin-sidebar">
    <div class="sidebar-header">
        <i class="fas fa-crown"></i>
        <h3>Админ цэс</h3>
    </div>
    <nav class="sidebar-nav">
        <a href="<?= $baseUrl ?>/pages/admin/dashboard.php" class="sidebar-link <?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">
            <i class="fas fa-tachometer-alt"></i> Хянах самбар
        </a>
        <a href="<?= $baseUrl ?>/pages/admin/rooms.php" class="sidebar-link <?= in_array($currentPage, ['rooms.php','room-create.php','room-edit.php']) ? 'active' : '' ?>">
            <i class="fas fa-door-open"></i> Өрөөнүүд
        </a>
        <a href="<?= $baseUrl ?>/pages/admin/categories.php" class="sidebar-link <?= $currentPage === 'categories.php' ? 'active' : '' ?>">
            <i class="fas fa-tags"></i> Ангилал
        </a>
        <a href="<?= $baseUrl ?>/pages/admin/products.php" class="sidebar-link <?= in_array($currentPage, ['products.php','product-create.php','product-edit.php']) ? 'active' : '' ?>">
            <i class="fas fa-box"></i> Бараа бүтээгдэхүүн
        </a>
        <a href="<?= $baseUrl ?>/pages/admin/receive.php" class="sidebar-link <?= $currentPage === 'receive.php' ? 'active' : '' ?>">
            <i class="fas fa-truck-loading"></i> Бараа хүлээн авах
        </a>
        <a href="<?= $baseUrl ?>/pages/admin/bookings.php" class="sidebar-link <?= $currentPage === 'bookings.php' ? 'active' : '' ?>">
            <i class="fas fa-calendar-check"></i> Захиалга
        </a>
        <a href="<?= $baseUrl ?>/pages/admin/bookings-archive.php" class="sidebar-link <?= $currentPage === 'bookings-archive.php' ? 'active' : '' ?>">
            <i class="fas fa-archive"></i> Архив
        </a>
        <a href="<?= $baseUrl ?>/pages/admin/orders.php" class="sidebar-link <?= $currentPage === 'orders.php' ? 'active' : '' ?>">
            <i class="fas fa-shopping-cart"></i> Борлуулалт
        </a>
        <a href="<?= $baseUrl ?>/pages/admin/users.php" class="sidebar-link <?= $currentPage === 'users.php' ? 'active' : '' ?>">
            <i class="fas fa-users"></i> Хэрэглэгчид
        </a>
        <a href="<?= $baseUrl ?>/pages/admin/settings.php" class="sidebar-link <?= $currentPage === 'settings.php' ? 'active' : '' ?>">
            <i class="fas fa-cog"></i> Тохиргоо
        </a>
    </nav>
</div>
