<?php
$pageTitle = 'Админ - Захиалгын тооцоо';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/database.php';
requireAdmin();

$base = getBaseUrl();
$id = intval($_GET['id'] ?? 0);
if (!$id) { header('Location: ' . $base . '/pages/admin/bookings.php'); exit; }

// Төлбөр баталгаажуулах: төлбөр paid. Pending бол confirmed болгоно. Нийт төлсөн >= нийт дүн бол completed
if (isset($_GET['payment_confirm'])) {
    $payId = intval($_GET['payment_confirm']);
    $p = $db->prepare("SELECT * FROM payments WHERE id = ? AND booking_id = ?");
    $p->execute([$payId, $id]);
    $pay = $p->fetch();
    if ($pay && $pay['status'] === 'pending') {
        $db->prepare("UPDATE payments SET status = 'paid' WHERE id = ?")->execute([$payId]);
        $bk = $db->prepare("SELECT status, total_price FROM bookings WHERE id = ?");
        $bk->execute([$id]);
        $bkRow = $bk->fetch();
        $grand = $db->prepare("SELECT b.total_price + COALESCE((SELECT SUM(o.total_price) FROM orders o WHERE o.booking_id = b.id AND o.status != 'cancelled'), 0) as gt FROM bookings b WHERE b.id = ?");
        $grand->execute([$id]);
        $grandTotal = (int) $grand->fetch()['gt'];
        $paidSum = $db->prepare("SELECT COALESCE(SUM(amount), 0) as t FROM payments WHERE booking_id = ? AND status = 'paid'");
        $paidSum->execute([$id]);
        $totalPaid = (int) $paidSum->fetch()['t'];
        if ($bkRow['status'] === 'pending') {
            $db->prepare("UPDATE bookings SET status = 'confirmed' WHERE id = ?")->execute([$id]);
        }
        if ($totalPaid >= $grandTotal) {
            $db->prepare("UPDATE bookings SET status = 'completed' WHERE id = ?")->execute([$id]);
            $db->prepare("UPDATE orders SET status = 'completed' WHERE booking_id = ? AND status = 'pending'")->execute([$id]);
        }
        header('Location: ' . $base . '/pages/admin/booking-detail.php?id=' . $id . '&paid=1');
        exit;
    }
}

// Бүгдийг төлөгдсөн болгох: бүх pending төлбөрийг paid болгоод, нийт хангалттай бол захиалга completed
if (isset($_GET['pay_all'])) {
    $db->prepare("UPDATE payments SET status = 'paid' WHERE booking_id = ? AND status = 'pending'")->execute([$id]);
    $grand = $db->prepare("SELECT b.total_price + COALESCE((SELECT SUM(o.total_price) FROM orders o WHERE o.booking_id = b.id AND o.status != 'cancelled'), 0) as gt FROM bookings b WHERE b.id = ?");
    $grand->execute([$id]);
    $grandTotal = (int) $grand->fetch()['gt'];
    $paidSum = $db->prepare("SELECT COALESCE(SUM(amount), 0) as t FROM payments WHERE booking_id = ? AND status = 'paid'");
    $paidSum->execute([$id]);
    $totalPaid = (int) $paidSum->fetch()['t'];
    $bk = $db->prepare("SELECT status FROM bookings WHERE id = ?");
    $bk->execute([$id]);
    $bkStatus = $bk->fetch()['status'];
    if ($bkStatus === 'pending') $db->prepare("UPDATE bookings SET status = 'confirmed' WHERE id = ?")->execute([$id]);
    if ($totalPaid >= $grandTotal) {
        $db->prepare("UPDATE bookings SET status = 'completed' WHERE id = ?")->execute([$id]);
        $db->prepare("UPDATE orders SET status = 'completed' WHERE booking_id = ? AND status = 'pending'")->execute([$id]);
    }
    header('Location: ' . $base . '/pages/admin/booking-detail.php?id=' . $id . '&paid=1');
    exit;
}

$booking = $db->prepare("
    SELECT b.*, u.username, u.fullname, u.phone as user_phone, r.name as room_name, r.price as room_price
    FROM bookings b JOIN users u ON b.user_id = u.id JOIN rooms r ON b.room_id = r.id
    WHERE b.id = ?
");
$booking->execute([$id]);
$booking = $booking->fetch();
if (!$booking) { header('Location: ' . $base . '/pages/admin/bookings.php'); exit; }

$orders = $db->prepare("
    SELECT o.* FROM orders o WHERE o.booking_id = ? ORDER BY o.created_at ASC
");
$orders->execute([$id]);
$orders = $orders->fetchAll();

$orderItems = [];
$productTotal = 0;
foreach ($orders as &$o) {
    $items = $db->prepare("SELECT oi.*, p.name as product_name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
    $items->execute([$o['id']]);
    $o['items'] = $items->fetchAll();
    if ($o['status'] !== 'cancelled') {
        $productTotal += $o['total_price'];
    }
}
unset($o);

$grandTotal = $booking['total_price'] + $productTotal;

$payments = $db->prepare("SELECT * FROM payments WHERE booking_id = ? ORDER BY created_at DESC");
$payments->execute([$id]);
$payments = $payments->fetchAll();

$totalPaid = 0;
foreach ($payments as $p) {
    if ($p['status'] === 'paid') $totalPaid += (int) $p['amount'];
}
$paymentBalance = $grandTotal - $totalPaid;

$timeline = [];
foreach ($payments as $p) {
    $timeline[] = ['type' => 'payment', 'date' => $p['created_at'], 'data' => $p];
}
foreach ($orders as $o) {
    if ($o['status'] === 'cancelled') continue;
    $timeline[] = ['type' => 'order', 'date' => $o['created_at'], 'data' => $o];
}
usort($timeline, function($a, $b) { return strcmp($b['date'], $a['date']); });

$statusLabels = [
    'pending' => ['Хүлээгдэж буй', 'badge-pending'],
    'confirmed' => ['Баталгаажсан', 'badge-confirmed'],
    'completed' => ['Дууссан', 'badge-completed'],
    'cancelled' => ['Цуцлагдсан', 'badge-cancelled']
];

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container">
    <div class="admin-page">
        <?php include __DIR__ . '/../../includes/admin-sidebar.php'; ?>

        <div class="admin-content">
            <div class="admin-content-header">
                <h1 class="admin-title"><i class="fas fa-file-invoice-dollar"></i> Захиалгын тооцоо</h1>
                <a href="<?= $baseUrl ?>/pages/admin/bookings.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Буцах</a>
            </div>

            <?php if (isset($_GET['paid'])): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> Төлбөр баталгаажлаа.<?= $paymentBalance <= 0 ? ' Захиалга дууссан боллоо.' : '' ?></div>
            <?php endif; ?>
            <?php if ($paymentBalance > 0 && in_array($booking['status'], ['pending', 'confirmed'])): ?>
                <div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> Төлбөрийн үлдэгдэл: <?= number_format($paymentBalance) ?>₮. Үлдэгдэл төлөгдөхгүй бол захиалга дуусгах боломжгүй.</div>
            <?php endif; ?>

            <?php $sl = $statusLabels[$booking['status']] ?? ['?', 'badge-user']; ?>

            <div class="form-card" style="margin-bottom: 24px;">
                <h3><i class="fas fa-door-open"></i> Өрөөний мэдээлэл</h3>
                <div class="bill-info-grid">
                    <div class="bill-info-item">
                        <span class="bill-label">Хэрэглэгч</span>
                        <span class="bill-value"><?= htmlspecialchars($booking['fullname'] ?? $booking['username']) ?>
                            <?php if ($booking['user_phone']): ?><br><small style="color:var(--text-muted)"><?= htmlspecialchars($booking['user_phone']) ?></small><?php endif; ?>
                        </span>
                    </div>
                    <div class="bill-info-item">
                        <span class="bill-label">Өрөө</span>
                        <span class="bill-value"><?= htmlspecialchars($booking['room_name']) ?></span>
                    </div>
                    <div class="bill-info-item">
                        <span class="bill-label">Огноо</span>
                        <span class="bill-value"><?= $booking['booking_date'] ?></span>
                    </div>
                    <div class="bill-info-item">
                        <span class="bill-label">Цаг</span>
                        <span class="bill-value"><?= $booking['start_time'] ?> - <?= $booking['end_time'] ?></span>
                    </div>
                    <div class="bill-info-item">
                        <span class="bill-label">Төлөв</span>
                        <span class="badge <?= $sl[1] ?>"><?= $sl[0] ?></span>
                    </div>
                </div>
            </div>

            <div class="form-card" style="margin-bottom: 24px;">
                <h3><i class="fas fa-receipt"></i> Тооцооны задаргаа</h3>

                <table class="data-table" style="margin-bottom: 0;">
                    <thead>
                        <tr><th>Нэр</th><th>Нэгж үнэ</th><th>Тоо</th><th style="text-align:right;">Дүн</th></tr>
                    </thead>
                    <tbody>
                        <tr style="background: rgba(108,60,225,0.05);">
                            <td><strong><i class="fas fa-door-open" style="color:var(--primary-light);"></i> <?= htmlspecialchars($booking['room_name']) ?></strong></td>
                            <td><?= number_format($booking['room_price']) ?>₮/цаг</td>
                            <td>
                                <?php
                                $sp = explode(':', $booking['start_time']);
                                $ep = explode(':', $booking['end_time']);
                                $hrs = ($ep[0]*60+$ep[1] - $sp[0]*60-$sp[1]) / 60;
                                echo round($hrs, 1) . ' цаг';
                                ?>
                            </td>
                            <td style="text-align:right;"><strong><?= number_format($booking['total_price']) ?>₮</strong></td>
                        </tr>

                        <?php foreach ($orders as $o): ?>
                            <?php if ($o['status'] === 'cancelled') continue; ?>
                            <?php foreach ($o['items'] as $item): ?>
                            <tr>
                                <td><i class="fas fa-utensils" style="color:var(--accent);"></i> <?= htmlspecialchars($item['product_name']) ?></td>
                                <td><?= number_format($item['price']) ?>₮</td>
                                <td><?= $item['quantity'] ?></td>
                                <td style="text-align:right;"><?= number_format($item['price'] * $item['quantity']) ?>₮</td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr style="border-top: 2px solid var(--border);">
                            <td colspan="3" style="text-align:right; font-weight: 700; font-size: 1rem;">Өрөөний үнэ:</td>
                            <td style="text-align:right; font-weight: 700; font-size: 1rem;"><?= number_format($booking['total_price']) ?>₮</td>
                        </tr>
                        <?php if ($productTotal > 0): ?>
                        <tr>
                            <td colspan="3" style="text-align:right; font-weight: 700; font-size: 1rem;">Бүтээгдэхүүний дүн:</td>
                            <td style="text-align:right; font-weight: 700; font-size: 1rem;"><?= number_format($productTotal) ?>₮</td>
                        </tr>
                        <?php endif; ?>
                        <tr style="background: rgba(16,185,129,0.08);">
                            <td colspan="3" style="text-align:right; font-weight: 800; font-size: 1.2rem; color: var(--text);">НИЙТ ДҮН:</td>
                            <td style="text-align:right; font-weight: 800; font-size: 1.3rem; color: var(--success);"><?= number_format($grandTotal) ?>₮</td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <div class="form-card" style="margin-bottom: 24px;">
                <h3><i class="fas fa-history"></i> Төлбөр ба захиалгын түүх</h3>
                <?php if (empty($timeline)): ?>
                    <p style="color: var(--text-muted); margin: 0;">Түүх байхгүй байна.</p>
                <?php else: ?>
                <table class="data-table">
                    <thead>
                        <tr><th>Огноо</th><th>Төрөл</th><th>Дэлгэрэнгүй</th><th>Дүн</th><th>Төлөв</th><th></th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($timeline as $t): ?>
                        <?php if ($t['type'] === 'payment'): $p = $t['data']; ?>
                        <tr>
                            <td><?= date('Y-m-d H:i', strtotime($p['created_at'])) ?></td>
                            <td><span class="badge badge-user"><i class="fas fa-credit-card"></i> Төлбөр</span></td>
                            <td><?= $p['payment_method'] === 'cash' ? 'Бэлэн мөнгөөр' : 'Дансаар шилжүүлэх' ?><?= $p['transaction_ref'] ? ' · ' . htmlspecialchars($p['transaction_ref']) : '' ?></td>
                            <td><strong><?= number_format($p['amount']) ?>₮</strong></td>
                            <td><span class="badge <?= $p['status'] === 'paid' ? 'badge-completed' : 'badge-pending' ?>"><?= $p['status'] === 'paid' ? 'Төлөгдсөн' : 'Хүлээгдэж буй' ?></span></td>
                            <td>
                                <?php if ($p['status'] === 'pending'): ?>
                                    <a href="<?= $baseUrl ?>/pages/admin/booking-detail.php?id=<?= $id ?>&payment_confirm=<?= $p['id'] ?>" class="btn btn-sm btn-primary" onclick="return confirm('Төлбөрийг баталгаажуулах уу?');">
                                        <i class="fas fa-check"></i> Баталгаажуулах
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php else: $o = $t['data']; ?>
                        <tr>
                            <td><?= date('Y-m-d H:i', strtotime($o['created_at'])) ?></td>
                            <td><span class="badge badge-confirmed"><i class="fas fa-utensils"></i> Бараа захиалга</span></td>
                            <td>
                                <?php
                                $names = [];
                                foreach ($o['items'] as $it) $names[] = $it['product_name'] . ' x' . $it['quantity'];
                                echo htmlspecialchars(implode(', ', $names));
                                ?>
                            </td>
                            <td><strong><?= number_format($o['total_price']) ?>₮</strong></td>
                            <td><span class="badge <?= $o['status'] === 'completed' ? 'badge-completed' : 'badge-pending' ?>"><?= $o['status'] === 'completed' ? 'Дууссан' : 'Хүлээгдэж буй' ?></span></td>
                            <td></td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php
                $hasPendingPayment = false;
                foreach ($payments as $p) { if ($p['status'] === 'pending') { $hasPendingPayment = true; break; } }
                if ($hasPendingPayment): ?>
                <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid var(--border);">
                    <a href="<?= $baseUrl ?>/pages/admin/booking-detail.php?id=<?= $id ?>&pay_all=1" class="btn btn-primary" onclick="return confirm('Бүх төлбөрийг төлөгдсөн болгох уу?');">
                        <i class="fas fa-check-double"></i> Бүгдийг төлөгдсөн болгох
                    </a>
                </div>
                <?php endif; ?>
                <?php endif; ?>
            </div>

            <?php if (in_array($booking['status'], ['pending', 'confirmed'])): ?>
            <div style="display: flex; gap: 12px; flex-wrap: wrap; align-items: center;">
                <?php if ($booking['status'] === 'pending'): ?>
                    <a href="<?= $baseUrl ?>/pages/admin/bookings.php?status_update=<?= $booking['id'] ?>&to=confirmed" class="btn btn-primary btn-lg"><i class="fas fa-check"></i> Батлах</a>
                <?php endif; ?>
                <?php if ($booking['status'] === 'confirmed'): ?>
                    <?php if ($paymentBalance <= 0): ?>
                        <a href="<?= $baseUrl ?>/pages/admin/bookings.php?status_update=<?= $booking['id'] ?>&to=completed" class="btn btn-primary btn-lg"><i class="fas fa-check-double"></i> Дуусгах (тооцоо хаах)</a>
                    <?php else: ?>
                        <span class="btn btn-lg btn-outline" style="cursor:not-allowed; opacity:0.7;" title="Төлбөрийн үлдэгдэл төлөгдсөн бол дуусгана"><i class="fas fa-lock"></i> Дуусгах (үлдэгдэл: <?= number_format($paymentBalance) ?>₮)</span>
                    <?php endif; ?>
                <?php endif; ?>
                <a href="<?= $baseUrl ?>/pages/admin/bookings.php?status_update=<?= $booking['id'] ?>&to=cancelled" class="btn btn-outline btn-lg"><i class="fas fa-ban"></i> Цуцлах</a>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
