<?php
$pageTitle = 'Бүртгүүлэх';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';

$base = getBaseUrl();

if (isLoggedIn()) {
    header('Location: ' . $base . '/');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';
    $phone = trim($_POST['phone'] ?? '');

    if (empty($username) || empty($password)) {
        $error = 'Бүх талбарыг бөглөнө үү';
    } elseif ($password !== $password2) {
        $error = 'Нууц үг таарахгүй байна';
    } elseif (strlen($password) < 4) {
        $error = 'Нууц үг хамгийн багадаа 4 тэмдэгт байна';
    } else {
        $check = $db->prepare('SELECT id FROM users WHERE username = ?');
        $check->execute([$username]);
        if ($check->fetch()) {
            $error = 'Энэ нэвтрэх нэр бүртгэлтэй байна';
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $db->prepare('INSERT INTO users (username, password, role, phone) VALUES (?, ?, ?, ?)');
            $stmt->execute([$username, $hashed, 'user', $phone ?: null]);
            $success = 'Амжилттай бүртгэгдлээ! Одоо нэвтрэх боломжтой.';
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container">
    <div class="auth-wrapper">
        <div class="auth-card">
            <div class="auth-header">
                <i class="fas fa-user-plus auth-icon"></i>
                <h2>Бүртгүүлэх</h2>
                <p>Шинэ хэрэглэгч бүртгэх</p>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?= $error ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?= $success ?>
                    <br><a href="<?= $baseUrl ?>/pages/login.php">Нэвтрэх хуудас руу очих</a>
                </div>
            <?php endif; ?>

            <form method="POST" class="auth-form">
                <div class="form-group">
                    <label for="username">
                        <i class="fas fa-user"></i> Нэвтрэх нэр
                    </label>
                    <input type="text" id="username" name="username" class="form-control"
                           placeholder="Нэвтрэх нэрээ оруулна уу" required
                           value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="phone">
                        <i class="fas fa-phone"></i> Утасны дугаар
                    </label>
                    <input type="text" id="phone" name="phone" class="form-control"
                           placeholder="Утасны дугаараа оруулна уу"
                           value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="password">
                        <i class="fas fa-lock"></i> Нууц үг
                    </label>
                    <input type="password" id="password" name="password" class="form-control"
                           placeholder="Нууц үгээ оруулна уу" required>
                </div>
                <div class="form-group">
                    <label for="password2">
                        <i class="fas fa-lock"></i> Нууц үг давтах
                    </label>
                    <input type="password" id="password2" name="password2" class="form-control"
                           placeholder="Нууц үгээ дахин оруулна уу" required>
                </div>
                <button type="submit" class="btn btn-primary btn-block btn-lg">
                    <i class="fas fa-user-plus"></i> Бүртгүүлэх
                </button>
            </form>
            <div class="auth-footer">
                <p>Бүртгэлтэй юу? <a href="<?= $baseUrl ?>/pages/login.php">Нэвтрэх</a></p>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
