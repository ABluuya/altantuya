<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';

$base = getBaseUrl();
$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: ' . $base . '/');
    exit;
}

$stmt = $db->prepare('SELECT * FROM rooms WHERE id = ?');
$stmt->execute([$id]);
$room = $stmt->fetch();

if (!$room) {
    header('Location: ' . $base . '/');
    exit;
}

$imgStmt = $db->prepare('SELECT * FROM room_images WHERE room_id = ?');
$imgStmt->execute([$id]);
$images = $imgStmt->fetchAll();

$pageTitle = htmlspecialchars($room['name']) . ' - Караоке';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="container">
    <div class="room-detail">
        <a href="<?= $baseUrl ?>/" class="btn btn-outline btn-back">
            <i class="fas fa-arrow-left"></i> Буцах
        </a>

        <div class="room-detail-header">
            <div>
                <?php if (!empty($room['is_vip'])): ?>
                    <span class="vip-detail-badge"><i class="fas fa-crown"></i> VIP</span>
                <?php endif; ?>
                <h1><?= htmlspecialchars($room['name']) ?></h1>
            </div>
            <div class="room-detail-price <?= !empty($room['is_vip']) ? 'vip-price' : '' ?>">
                <i class="fas fa-tag"></i>
                <span><?= number_format($room['price']) ?>₮/цаг</span>
            </div>
        </div>

        <div class="room-detail-gallery">
            <div class="gallery-main">
                <?php if ($room['featured_image']): ?>
                    <img id="mainImage" src="<?= $baseUrl ?>/uploads/rooms/<?= htmlspecialchars($room['featured_image']) ?>"
                         alt="<?= htmlspecialchars($room['name']) ?>">
                <?php else: ?>
                    <div class="gallery-placeholder">
                        <i class="fas fa-microphone-alt"></i>
                    </div>
                <?php endif; ?>
            </div>

            <?php if (!empty($images) || $room['featured_image']): ?>
                <div class="gallery-thumbs">
                    <?php if ($room['featured_image']): ?>
                        <div class="gallery-thumb active" onclick="changeMainImage(this)">
                            <img src="<?= $baseUrl ?>/uploads/rooms/<?= htmlspecialchars($room['featured_image']) ?>"
                                 alt="Үндсэн зураг">
                        </div>
                    <?php endif; ?>
                    <?php foreach ($images as $img): ?>
                        <div class="gallery-thumb" onclick="changeMainImage(this)">
                            <img src="<?= $baseUrl ?>/uploads/rooms/<?= htmlspecialchars($img['image_path']) ?>"
                                 alt="Нэмэлт зураг">
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="room-detail-info">
            <h2><i class="fas fa-info-circle"></i> Дэлгэрэнгүй мэдээлэл</h2>
            <div class="room-description">
                <?= nl2br(htmlspecialchars($room['description'])) ?>
            </div>
        </div>

        <div style="margin-top: 24px; display: flex; gap: 12px; flex-wrap: wrap;">
            <?php if (isLoggedIn()): ?>
                <a href="<?= $baseUrl ?>/pages/booking.php?room_id=<?= $room['id'] ?>" class="btn btn-primary btn-lg">
                    <i class="fas fa-calendar-check"></i> Энэ өрөөг захиалах
                </a>
            <?php else: ?>
                <a href="<?= $baseUrl ?>/pages/login.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-sign-in-alt"></i> Нэвтэрч захиалах
                </a>
            <?php endif; ?>
            <a href="<?= $baseUrl ?>/" class="btn btn-outline btn-lg">
                <i class="fas fa-arrow-left"></i> Бусад өрөөнүүд
            </a>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
