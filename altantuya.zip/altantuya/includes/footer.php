    </main>
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-brand">
                    <i class="fas fa-microphone-alt"></i>
                    <span>Алтантуяа Караоке</span>
                </div>
                <p>&copy; <?= date('Y') ?> Бүх эрх хуулиар хамгаалагдсан.</p>
            </div>
        </div>
    </footer>
    <script src="<?= $baseUrl ?>/assets/js/main.js"></script>
</body>
</html>
