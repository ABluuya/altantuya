<?php
$host = 'localhost';
$dbname = 'karaoke_db';
$username = 'root';
$password = '';

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('Мэдээллийн сантай холбогдож чадсангүй: ' . $e->getMessage());
}

$adminCheck = $db->prepare('SELECT id FROM users WHERE role = ?');
$adminCheck->execute(['admin']);
if (!$adminCheck->fetch()) {
    $hashedPassword = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = $db->prepare('INSERT INTO users (username, password, role, fullname) VALUES (?, ?, ?, ?)');
    $stmt->execute(['admin', $hashedPassword, 'admin', 'Админ']);
}
