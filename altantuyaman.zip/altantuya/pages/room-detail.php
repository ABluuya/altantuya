<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';

$base = getBaseUrl();
$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: ' . $base . '/');
    exit;
}

$stmt = $db->prepare('SELECT * FROM rooms WHERE id = ?');
$stmt->execute([$id]);
$room = $stmt->fetch();

if (!$room) {
    header('Location: ' . $base . '/');
    exit;
}

$imgStmt = $db->prepare('SELECT * FROM room_images WHERE room_id = ?');
$imgStmt->execute([$id]);
$images = $imgStmt->fetchAll();

$pageTitle = htmlspecialchars($room['name']) . ' - Караоке';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="container">
    <div class="room-detail">
        <a href="<?= $baseUrl ?>/" class="btn btn-outline btn-back">
            <i class="fas fa-arrow-left"></i> Буцах
        </a>

        <div class="room-detail-header">
            <h1><?= htmlspecialchars($room['name']) ?></h1>
            <div class="room-detail-price">
                <i class="fas fa-tag"></i>
                <span><?= number_format($room['price']) ?>₮</span>
            </div>
        </div>

        <div class="room-detail-gallery">
            <div class="gallery-main">
                <?php if ($room['featured_image']): ?>
                    <img id="mainImage" src="<?= $baseUrl ?>/uploads/rooms/<?= htmlspecialchars($room['featured_image']) ?>"
                         alt="<?= htmlspecialchars($room['name']) ?>">
                <?php else: ?>
                    <div class="gallery-placeholder">
                        <i class="fas fa-microphone-alt"></i>
                    </div>
                <?php endif; ?>
            </div>

            <?php if (!empty($images) || $room['featured_image']): ?>
                <div class="gallery-thumbs">
                    <?php if ($room['featured_image']): ?>
                        <div class="gallery-thumb active" onclick="changeMainImage(this)">
                            <img src="<?= $baseUrl ?>/uploads/rooms/<?= htmlspecialchars($room['featured_image']) ?>"
                                 alt="Үндсэн зураг">
                        </div>
                    <?php endif; ?>
                    <?php foreach ($images as $img): ?>
                        <div class="gallery-thumb" onclick="changeMainImage(this)">
                            <img src="<?= $baseUrl ?>/uploads/rooms/<?= htmlspecialchars($img['image_path']) ?>"
                                 alt="Нэмэлт зураг">
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="room-detail-info">
            <h2><i class="fas fa-info-circle"></i> Дэлгэрэнгүй мэдээлэл</h2>
            <div class="room-description">
                <?= nl2br(htmlspecialchars($room['description'])) ?>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
