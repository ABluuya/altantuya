<?php
$pageTitle = 'Админ - Борлуулалт';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/database.php';
requireAdmin();

$base = getBaseUrl();

if (isset($_GET['status_update'])) {
    $oId = intval($_GET['status_update']);
    $newStatus = $_GET['to'] ?? '';
    $valid = ['pending', 'completed', 'cancelled'];
    if ($oId && in_array($newStatus, $valid)) {
        $db->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([$newStatus, $oId]);
    }
    header('Location: ' . $base . '/pages/admin/orders.php');
    exit;
}

if (isset($_GET['delete'])) {
    $db->prepare('DELETE FROM orders WHERE id = ?')->execute([intval($_GET['delete'])]);
    header('Location: ' . $base . '/pages/admin/orders.php?deleted=1');
    exit;
}

$orders = $db->query("
    SELECT o.*, u.username, u.fullname,
           (SELECT GROUP_CONCAT(CONCAT(p.name, ' x', oi.quantity) SEPARATOR ', ')
            FROM order_items oi JOIN products p ON oi.product_id = p.id
            WHERE oi.order_id = o.id) as items_summary
    FROM orders o
    JOIN users u ON o.user_id = u.id
    ORDER BY o.created_at DESC
")->fetchAll();

$statusLabels = [
    'pending' => ['Хүлээгдэж буй', 'badge-pending'],
    'completed' => ['Дууссан', 'badge-completed'],
    'cancelled' => ['Цуцлагдсан', 'badge-cancelled']
];

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container">
    <div class="admin-page">
        <?php include __DIR__ . '/../../includes/admin-sidebar.php'; ?>

        <div class="admin-content">
            <h1 class="admin-title"><i class="fas fa-shopping-cart"></i> Борлуулалт</h1>

            <?php if (isset($_GET['deleted'])): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> Захиалга устгагдлаа</div>
            <?php endif; ?>

            <?php if (empty($orders)): ?>
                <div class="empty-state">
                    <i class="fas fa-shopping-cart"></i>
                    <h3>Борлуулалт байхгүй байна</h3>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Хэрэглэгч</th>
                                <th>Бараанууд</th>
                                <th>Дүн</th>
                                <th>Төлөв</th>
                                <th>Огноо</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $i => $o): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td><strong><?= htmlspecialchars($o['fullname'] ?? $o['username']) ?></strong></td>
                                <td><small style="line-height:1.4;display:block;max-width:200px;"><?= htmlspecialchars($o['items_summary'] ?? '-') ?></small></td>
                                <td><strong style="color:var(--success);"><?= number_format($o['total_price']) ?>₮</strong></td>
                                <td>
                                    <?php $sl = $statusLabels[$o['status']] ?? ['?', 'badge-user']; ?>
                                    <span class="badge <?= $sl[1] ?>"><?= $sl[0] ?></span>
                                </td>
                                <td><small><?= date('m/d H:i', strtotime($o['created_at'])) ?></small></td>
                                <td>
                                    <div class="action-buttons">
                                        <?php if ($o['status'] === 'pending'): ?>
                                            <a href="<?= $baseUrl ?>/pages/admin/orders.php?status_update=<?= $o['id'] ?>&to=completed" class="btn btn-sm btn-primary"><i class="fas fa-check"></i></a>
                                            <a href="<?= $baseUrl ?>/pages/admin/orders.php?status_update=<?= $o['id'] ?>&to=cancelled" class="btn btn-sm btn-outline"><i class="fas fa-ban"></i></a>
                                        <?php endif; ?>
                                        <a href="<?= $baseUrl ?>/pages/admin/orders.php?delete=<?= $o['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Устгах уу?')"><i class="fas fa-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
