<?php
$pageTitle = 'Админ - Шинэ өрөө нэмэх';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/database.php';
requireAdmin();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $price = intval($_POST['price'] ?? 0);
    $description = trim($_POST['description'] ?? '');

    if (empty($name) || $price <= 0) {
        $error = 'Өрөөний нэр болон үнийг зөв оруулна уу';
    } else {
        $featuredImage = null;
        $uploadDir = __DIR__ . '/../../uploads/rooms/';

        if (!empty($_FILES['featured_image']['name'])) {
            $ext = strtolower(pathinfo($_FILES['featured_image']['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            if (in_array($ext, $allowed)) {
                $featuredImage = 'featured_' . time() . '_' . uniqid() . '.' . $ext;
                move_uploaded_file($_FILES['featured_image']['tmp_name'], $uploadDir . $featuredImage);
            } else {
                $error = 'Зөвхөн JPG, PNG, GIF, WEBP зураг оруулна уу';
            }
        }

        if (empty($error)) {
            $stmt = $db->prepare('INSERT INTO rooms (name, price, description, featured_image) VALUES (?, ?, ?, ?)');
            $stmt->execute([$name, $price, $description, $featuredImage]);
            $roomId = $db->lastInsertId();

            if (!empty($_FILES['other_images']['name'][0])) {
                $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                foreach ($_FILES['other_images']['name'] as $i => $fileName) {
                    if ($_FILES['other_images']['error'][$i] === UPLOAD_ERR_OK) {
                        $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                        if (in_array($ext, $allowed)) {
                            $newName = 'room_' . $roomId . '_' . time() . '_' . $i . '.' . $ext;
                            move_uploaded_file($_FILES['other_images']['tmp_name'][$i], $uploadDir . $newName);
                            $db->prepare('INSERT INTO room_images (room_id, image_path) VALUES (?, ?)')->execute([$roomId, $newName]);
                        }
                    }
                }
            }

            header('Location: ' . getBaseUrl() . '/pages/admin/rooms.php?created=1');
            exit;
        }
    }
}

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container">
    <div class="admin-page">
        <div class="admin-sidebar">
            <div class="sidebar-header">
                <i class="fas fa-crown"></i>
                <h3>Админ цэс</h3>
            </div>
            <nav class="sidebar-nav">
                <a href="<?= $baseUrl ?>/pages/admin/dashboard.php" class="sidebar-link">
                    <i class="fas fa-tachometer-alt"></i> Хянах самбар
                </a>
                <a href="<?= $baseUrl ?>/pages/admin/rooms.php" class="sidebar-link active">
                    <i class="fas fa-door-open"></i> Өрөөнүүд
                </a>
                <a href="<?= $baseUrl ?>/pages/admin/users.php" class="sidebar-link">
                    <i class="fas fa-users"></i> Хэрэглэгчид
                </a>
            </nav>
        </div>

        <div class="admin-content">
            <div class="admin-content-header">
                <h1 class="admin-title">
                    <i class="fas fa-plus-circle"></i> Шинэ өрөө нэмэх
                </h1>
                <a href="<?= $baseUrl ?>/pages/admin/rooms.php" class="btn btn-outline">
                    <i class="fas fa-arrow-left"></i> Буцах
                </a>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?= $error ?>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" class="room-form">
                <div class="form-card">
                    <h3><i class="fas fa-info-circle"></i> Үндсэн мэдээлэл</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="name">Өрөөний нэр <span class="required">*</span></label>
                            <input type="text" id="name" name="name" class="form-control"
                                   placeholder="Жишээ: VIP 1-р өрөө" required
                                   value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label for="price">Үнэ (₮) <span class="required">*</span></label>
                            <input type="number" id="price" name="price" class="form-control"
                                   placeholder="Жишээ: 50000" required min="1"
                                   value="<?= htmlspecialchars($_POST['price'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="description">Дэлгэрэнгүй мэдээлэл</label>
                        <textarea id="description" name="description" class="form-control" rows="5"
                                  placeholder="Өрөөний тухай дэлгэрэнгүй мэдээлэл оруулна уу..."><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
                    </div>
                </div>

                <div class="form-card">
                    <h3><i class="fas fa-image"></i> Үндсэн зураг</h3>
                    <div class="upload-area" id="featuredUploadArea">
                        <input type="file" id="featured_image" name="featured_image" accept="image/*"
                               onchange="previewFeaturedImage(this)">
                        <div class="upload-placeholder" id="featuredPlaceholder">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <p>Зураг сонгохын тулд дарна уу</p>
                            <span>JPG, PNG, GIF, WEBP</span>
                        </div>
                        <div class="upload-preview" id="featuredPreview" style="display:none;">
                            <img id="featuredPreviewImg" src="" alt="">
                            <button type="button" class="btn btn-sm btn-danger remove-preview"
                                    onclick="removeFeaturedImage()">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="form-card">
                    <h3><i class="fas fa-images"></i> Бусад зурагнууд</h3>
                    <p class="form-help">Хэдэн ч зураг оруулах боломжтой</p>
                    <div class="upload-area" id="otherUploadArea">
                        <input type="file" id="other_images" name="other_images[]" accept="image/*" multiple
                               onchange="previewOtherImages(this)">
                        <div class="upload-placeholder" id="otherPlaceholder">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <p>Зургуудаа сонгоно уу (олон зураг сонгож болно)</p>
                            <span>JPG, PNG, GIF, WEBP</span>
                        </div>
                    </div>
                    <div class="upload-previews-grid" id="otherPreviews"></div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-save"></i> Хадгалах
                    </button>
                    <a href="<?= $baseUrl ?>/pages/admin/rooms.php" class="btn btn-outline btn-lg">Цуцлах</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
