<?php
$pageTitle = 'Өрөө захиалах';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
requireLogin();

$base = getBaseUrl();
$roomId = intval($_GET['room_id'] ?? 0);

$rooms = $db->query("SELECT * FROM rooms WHERE status = 'available' ORDER BY name")->fetchAll();

$selectedRoom = null;
if ($roomId) {
    $stmt = $db->prepare('SELECT * FROM rooms WHERE id = ? AND status = ?');
    $stmt->execute([$roomId, 'available']);
    $selectedRoom = $stmt->fetch();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $room_id = intval($_POST['room_id'] ?? 0);
    $booking_date = $_POST['booking_date'] ?? '';
    $selectedSlots = $_POST['slots'] ?? [];
    $note = trim($_POST['note'] ?? '');

    if (!$room_id || empty($booking_date) || empty($selectedSlots)) {
        $error = 'Өрөө, огноо, цаг сонгоно уу';
    } else {
        $roomStmt = $db->prepare('SELECT * FROM rooms WHERE id = ?');
        $roomStmt->execute([$room_id]);
        $room = $roomStmt->fetch();

        if (!$room) {
            $error = 'Өрөө олдсонгүй';
        } else {
            sort($selectedSlots);
            $hours = array_map('intval', $selectedSlots);

            $bookedCheck = $db->prepare("SELECT start_time, end_time FROM bookings WHERE room_id = ? AND booking_date = ? AND status IN ('pending','confirmed')");
            $bookedCheck->execute([$room_id, $booking_date]);
            $existingBookings = $bookedCheck->fetchAll();

            $alreadyBooked = [];
            foreach ($existingBookings as $eb) {
                $sh = intval(explode(':', $eb['start_time'])[0]);
                $eh = intval(explode(':', $eb['end_time'])[0]);
                for ($h = $sh; $h < $eh; $h++) {
                    $alreadyBooked[] = $h;
                }
            }

            $conflict = array_intersect($hours, $alreadyBooked);
            if (!empty($conflict)) {
                $error = 'Сонгосон цагуудын зарим нь аль хэдийн захиалагдсан байна';
            } else {
                $startTime = sprintf('%02d:00', min($hours));
                $endTime = sprintf('%02d:00', max($hours) + 1);
                $totalHours = count($hours);
                $totalPrice = $room['price'] * $totalHours;

                $stmt = $db->prepare('INSERT INTO bookings (user_id, room_id, booking_date, start_time, end_time, total_price, status, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
                $stmt->execute([currentUser()['id'], $room_id, $booking_date, $startTime, $endTime, $totalPrice, 'pending', $note ?: null]);
                $success = "Захиалга амжилттай илгээгдлээ! $totalHours цаг × " . number_format($room['price']) . "₮ = " . number_format($totalPrice) . "₮";
            }
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container">
    <div style="max-width: 750px; margin: 40px auto; padding-bottom: 40px;">
        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; margin-bottom: 20px;">
            <a href="<?= $baseUrl ?>/" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Буцах</a>
            <a href="<?= $baseUrl ?>/pages/my-bookings.php" class="btn btn-outline">
                <i class="fas fa-list"></i> Миний захиалгууд
            </a>
        </div>

        <div class="form-card">
            <h3><i class="fas fa-calendar-check"></i> Өрөө захиалах</h3>

            <?php if ($error): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= $error ?></div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= $success ?></div>
            <?php endif; ?>

            <form method="POST" id="booking-form">
                <div class="form-group">
                    <label><i class="fas fa-door-open"></i> Өрөө сонгох <span class="required">*</span></label>
                    <select name="room_id" id="booking-room" class="form-control" required onchange="loadSlots()">
                        <option value="">-- Өрөө сонгоно уу --</option>
                        <?php foreach ($rooms as $r): ?>
                            <option value="<?= $r['id'] ?>" data-price="<?= $r['price'] ?>"
                                <?= ($selectedRoom && $selectedRoom['id'] == $r['id']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($r['name']) ?> - <?= number_format($r['price']) ?>₮/цаг
                                <?= $r['capacity'] ? ' (' . $r['capacity'] . ' хүн)' : '' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-calendar"></i> Огноо <span class="required">*</span></label>
                    <input type="date" name="booking_date" id="booking-date" class="form-control" required
                           min="<?= date('Y-m-d') ?>" value="<?= date('Y-m-d') ?>" onchange="loadSlots()">
                </div>

                <div id="slots-container" style="display: none; margin-top: 16px;">
                    <label style="font-weight: 600; font-size: 0.9rem; margin-bottom: 12px; display: block;">
                        <i class="fas fa-clock" style="color: var(--primary-light);"></i> Цаг сонгох <span class="required">*</span>
                        <span style="font-weight: 400; color: var(--text-muted); font-size: 0.8rem;"> — хэдэн ч цаг сонгож болно</span>
                    </label>

                    <div class="timeslot-legend">
                        <span class="legend-item"><span class="legend-dot legend-free"></span> Сул</span>
                        <span class="legend-item"><span class="legend-dot legend-booked"></span> Захиалагдсан</span>
                        <span class="legend-item"><span class="legend-dot legend-selected"></span> Таны сонголт</span>
                    </div>

                    <div id="slots-grid" class="timeslots-grid"></div>

                    <div id="slots-loading" style="text-align: center; padding: 20px; color: var(--text-muted); display: none;">
                        <i class="fas fa-spinner fa-spin"></i> Ачаалж байна...
                    </div>
                </div>

                <div id="booking-summary" style="display: none; margin-top: 16px;">
                    <div class="receive-total-display">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="font-size: 0.9rem; font-weight: 500; color: var(--text-muted);">Нийт үнэ:</span>
                            <span id="booking-total" style="font-size: 1.4rem;">0₮</span>
                        </div>
                        <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 4px;" id="booking-detail-text"></div>
                    </div>
                </div>

                <div class="form-group" style="margin-top: 16px;">
                    <label><i class="fas fa-sticky-note"></i> Нэмэлт тэмдэглэл</label>
                    <textarea name="note" class="form-control" rows="2" placeholder="Нэмэлт хүсэлт..."><?= htmlspecialchars($_POST['note'] ?? '') ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary btn-block btn-lg" id="submit-btn" disabled>
                    <i class="fas fa-paper-plane"></i> Захиалга илгээх
                </button>
            </form>
        </div>
    </div>
</div>

<script>
const baseUrl = '<?= $baseUrl ?>';
const OPEN_HOUR = 10;
const CLOSE_HOUR = 24;

function loadSlots() {
    const roomId = document.getElementById('booking-room').value;
    const date = document.getElementById('booking-date').value;
    const container = document.getElementById('slots-container');
    const grid = document.getElementById('slots-grid');
    const loading = document.getElementById('slots-loading');

    if (!roomId || !date) {
        container.style.display = 'none';
        document.getElementById('booking-summary').style.display = 'none';
        document.getElementById('submit-btn').disabled = true;
        return;
    }

    container.style.display = 'block';
    grid.innerHTML = '';
    loading.style.display = 'block';

    fetch(baseUrl + '/api/timeslots.php?room_id=' + roomId + '&date=' + date)
        .then(r => r.json())
        .then(data => {
            loading.style.display = 'none';
            if (!data.success) return;

            const bookedHours = data.booked_hours || [];

            for (let h = OPEN_HOUR; h < CLOSE_HOUR; h++) {
                const isBooked = bookedHours.includes(h);
                const label = document.createElement('label');
                label.className = 'timeslot' + (isBooked ? ' booked' : '');

                const endH = h + 1;
                const timeStr = (h < 10 ? '0' : '') + h + ':00 - ' + (endH < 10 ? '0' : '') + endH + ':00';

                if (isBooked) {
                    label.innerHTML =
                        '<span class="timeslot-time">' + timeStr + '</span>' +
                        '<span class="timeslot-status booked-text"><i class="fas fa-lock"></i> Захиалагдсан</span>';
                } else {
                    label.innerHTML =
                        '<input type="checkbox" name="slots[]" value="' + h + '" onchange="updateSummary()">' +
                        '<span class="timeslot-time">' + timeStr + '</span>' +
                        '<span class="timeslot-status free-text"><i class="fas fa-check-circle"></i> Сул</span>';
                }

                grid.appendChild(label);
            }

            updateSummary();
        });
}

function updateSummary() {
    const checked = document.querySelectorAll('#slots-grid input:checked');
    const summary = document.getElementById('booking-summary');
    const submitBtn = document.getElementById('submit-btn');

    if (checked.length === 0) {
        summary.style.display = 'none';
        submitBtn.disabled = true;
        return;
    }

    const roomSelect = document.getElementById('booking-room');
    const price = parseInt(roomSelect.options[roomSelect.selectedIndex]?.dataset?.price || 0);
    const total = price * checked.length;

    const hours = Array.from(checked).map(c => parseInt(c.value)).sort((a, b) => a - b);
    const startH = hours[0];
    const endH = hours[hours.length - 1] + 1;

    summary.style.display = 'block';
    submitBtn.disabled = false;
    document.getElementById('booking-total').textContent = total.toLocaleString() + '₮';
    document.getElementById('booking-detail-text').textContent =
        checked.length + ' цаг × ' + price.toLocaleString() + '₮ (' +
        (startH < 10 ? '0' : '') + startH + ':00 - ' + (endH < 10 ? '0' : '') + endH + ':00)';
}

document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('booking-room').value) loadSlots();
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
