<?php
/**
 * Холбоо барих мэдээлэл
 * Утасны дугаар болон Google Maps embed URL-ийг энд засварлана
 */
return [
    'phone' => '99119911',
    'phone_display' => '9911-9911',
    'google_maps_embed' => 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d10688.0!2d106.9159!3d47.9214!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDfCsDU1JzE3LjAiTiAxMDbCsDU0JzU3LjIiRQ!5e0!3m2!1sen!2smn!4v1', // Google Maps → Share → Embed map-аас хуулна
];
