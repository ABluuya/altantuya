<?php
$pageTitle = 'Төлбөр төлөх';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';
requireLogin();

$base = getBaseUrl();
$userId = currentUser()['id'];
require_once __DIR__ . '/../config/settings.php';
$paymentConfig = getPaymentConfig();

// Төлөгдөөгүй захиалгууд (pending, confirmed)
$unpaidBookings = $db->prepare("
    SELECT b.*, r.name as room_name
    FROM bookings b
    JOIN rooms r ON b.room_id = r.id
    WHERE b.user_id = ? AND b.status IN ('pending', 'confirmed')
    ORDER BY b.booking_date ASC, b.start_time ASC
");
$unpaidBookings->execute([$userId]);
$unpaidBookings = $unpaidBookings->fetchAll();

foreach ($unpaidBookings as &$b) {
    $productTotal = $db->prepare("SELECT COALESCE(SUM(total_price), 0) as t FROM orders WHERE booking_id = ? AND status != 'cancelled'");
    $productTotal->execute([$b['id']]);
    $b['product_total'] = (int) $productTotal->fetch()['t'];
    $b['grand_total'] = $b['total_price'] + $b['product_total'];
    $paidSum = $db->prepare("SELECT COALESCE(SUM(amount), 0) as t FROM payments WHERE booking_id = ? AND status = 'paid'");
    $paidSum->execute([$b['id']]);
    $b['total_paid'] = (int) $paidSum->fetch()['t'];
    $b['balance'] = $b['grand_total'] - $b['total_paid'];
}
unset($b);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($unpaidBookings)) {
    $bookingId = intval($_POST['booking_id'] ?? 0);
    $method = trim($_POST['payment_method'] ?? '');
    $transactionRef = trim($_POST['transaction_ref'] ?? '');
    $note = trim($_POST['note'] ?? '');

    $booking = null;
    foreach ($unpaidBookings as $ub) {
        if ($ub['id'] == $bookingId) { $booking = $ub; break; }
    }

    if (!$booking || !in_array($method, ['cash', 'bank_transfer'])) {
        $error = 'Захиалга эсвэл төлбөрийн арга буруу байна';
    } elseif ($method === 'bank_transfer' && empty($transactionRef)) {
        $error = 'Дансаар шилжүүлэхэд утасны дугаар оруулах шаардлагатай';
    } else {
        $paidSum = $db->prepare("SELECT COALESCE(SUM(amount), 0) as t FROM payments WHERE booking_id = ? AND status = 'paid'");
        $paidSum->execute([$bookingId]);
        $totalPaid = (int) $paidSum->fetch()['t'];
        $balance = $booking['grand_total'] - $totalPaid;
        $amount = max(0, $balance);
        if ($amount <= 0) {
            $error = 'Энэ захиалгын төлбөр бүгд төлөгдсөн байна.';
        } else {
            $stmt = $db->prepare('INSERT INTO payments (booking_id, user_id, amount, payment_method, transaction_ref, status, note) VALUES (?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute([$bookingId, $userId, $amount, $method, $transactionRef ?: null, 'pending', $note ?: null]);

            $methodLabel = $method === 'cash' ? 'Бэлэн мөнгөөр' : 'Дансаар шилжүүлэх';
            $success = "Төлбөрийн хүсэлт илгээгдлээ! Арга: {$methodLabel}. Дүн: " . number_format($amount) . "₮";
            header('Location: ' . $base . '/pages/payment.php?success=1');
            exit;
        }
    }
}

if (isset($_GET['success'])) {
    $success = 'Төлбөрийн хүсэлт амжилттай илгээгдлээ. Таны төлбөрийг баталгаажуулсны дараа захиалга дууссан болно.';
}
if (isset($_GET['order_success'])) {
    $success = 'Захиалга амжилттай илгээгдлээ! Үлдэгдлийг доор төлнө үү.';
}
$scrollBookingId = intval($_GET['booking_id'] ?? 0);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container">
    <div style="max-width: 800px; margin: 40px auto; padding-bottom: 40px;">
        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; margin-bottom: 24px;">
            <h1 style="font-size: 1.6rem; font-weight: 700; color: var(--text);">
                <i class="fas fa-credit-card" style="color: var(--primary-light);"></i> Төлбөр төлөх
            </h1>
            <a href="<?= $baseUrl ?>/pages/my-bookings.php" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> Миний захиалгууд
            </a>
        </div>

        <div class="payment-info-banner">
            <i class="fas fa-info-circle"></i>
            Өрөө болон бүтээгдэхүүний үнийг нэг ёсоор төгсгөлд нь төлнө. Бүтээгдэхүүн нэмж захиалсан бол үлдэгдлийг дахин төлнө. Төлбөрийн үлдэгдэлтэй бол захиалга дуусахгүй.
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if (empty($unpaidBookings)): ?>
            <div class="empty-state">
                <i class="fas fa-check-circle" style="font-size: 4rem; color: var(--success);"></i>
                <h3>Төлөгдөөгүй захиалга байхгүй байна</h3>
                <p>Танд төлөх захиалга одоогоор байхгүй байна.</p>
                <a href="<?= $baseUrl ?>/pages/booking.php" class="btn btn-primary">
                    <i class="fas fa-calendar-check"></i> Өрөө захиалах
                </a>
            </div>
        <?php else: ?>
            <div class="payment-section">
                <?php foreach ($unpaidBookings as $b): ?>
                    <?php
                    $existingPayment = $db->prepare("SELECT * FROM payments WHERE booking_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT 1");
                    $existingPayment->execute([$b['id'], $userId]);
                    $lastPayment = $existingPayment->fetch();
                    ?>
                    <div class="form-card payment-card" id="booking-<?= $b['id'] ?>">
                        <div class="payment-card-header">
                            <h3><i class="fas fa-door-open"></i> <?= htmlspecialchars($b['room_name']) ?></h3>
                            <span class="payment-date"><?= date('Y-m-d', strtotime($b['booking_date'])) ?> · <?= $b['start_time'] ?> - <?= $b['end_time'] ?></span>
                        </div>

                        <div class="payment-summary">
                            <div class="payment-row">
                                <span>Өрөөний үнэ</span>
                                <strong><?= number_format($b['total_price']) ?>₮</strong>
                            </div>
                            <?php if ($b['product_total'] > 0): ?>
                                <div class="payment-row">
                                    <span>Бүтээгдэхүүн</span>
                                    <strong><?= number_format($b['product_total']) ?>₮</strong>
                                </div>
                            <?php endif; ?>
                            <div class="payment-row payment-total">
                                <span>Нийт дүн</span>
                                <strong class="grand-total"><?= number_format($b['grand_total']) ?>₮</strong>
                            </div>
                            <?php if ($b['total_paid'] > 0): ?>
                                <div class="payment-row">
                                    <span>Төлөгдсөн</span>
                                    <strong style="color: var(--success);"><?= number_format($b['total_paid']) ?>₮</strong>
                                </div>
                                <div class="payment-row payment-total">
                                    <span>Үлдэгдэл төлөх</span>
                                    <strong class="grand-total" style="color: var(--danger);"><?= number_format($b['balance']) ?>₮</strong>
                                </div>
                            <?php endif; ?>
                        </div>

                        <?php if ($b['balance'] <= 0): ?>
                            <div class="payment-status-info payment-success-msg">
                                <i class="fas fa-check-circle"></i>
                                <strong>Төлбөр амжилттай төлөгдлөө!</strong> Бүгд төлөгдсөн. Админ захиалгыг дуусгах хүртэл хүлээнэ үү.
                            </div>
                        <?php elseif ($lastPayment && $lastPayment['status'] === 'pending'): ?>
                            <div class="payment-status-info">
                                <i class="fas fa-info-circle"></i>
                                Төлбөрийн хүсэлт илгээсэн: <?= $lastPayment['payment_method'] === 'cash' ? 'Бэлэн мөнгөөр' : 'Дансаар шилжүүлэх' ?>
                                <?php if ($lastPayment['transaction_ref']): ?> · Утас: <?= htmlspecialchars($lastPayment['transaction_ref']) ?><?php endif; ?>
                                (<?= date('Y-m-d H:i', strtotime($lastPayment['created_at'])) ?>) · <?= number_format($lastPayment['amount']) ?>₮
                            </div>
                        <?php else: ?>
                            <form method="post" class="payment-form">
                                <input type="hidden" name="booking_id" value="<?= $b['id'] ?>">
                                <p class="payment-amount-note"><strong>Төлөх дүн: <?= number_format($b['balance']) ?>₮</strong></p>

                                <div class="payment-methods">
                                    <label class="payment-method-option">
                                        <input type="radio" name="payment_method" value="cash" required>
                                        <span class="method-box">
                                            <i class="fas fa-money-bill-wave"></i>
                                            <strong>Бэлэн мөнгөөр</strong>
                                            <small>Ирэхдээ бэлэн мөнгөөр төлнө</small>
                                        </span>
                                    </label>
                                    <label class="payment-method-option">
                                        <input type="radio" name="payment_method" value="bank_transfer">
                                        <span class="method-box">
                                            <i class="fas fa-university"></i>
                                            <strong>Дансаар шилжүүлэх</strong>
                                            <small>Банкны данс руу шилжүүлнэ</small>
                                        </span>
                                    </label>
                                </div>

                                <div class="bank-details" id="bank-details-<?= $b['id'] ?>" style="display:none;">
                                    <div class="bank-info-box">
                                        <h4><i class="fas fa-university"></i> Банкны мэдээлэл</h4>
                                        <table class="bank-table">
                                            <tr><td>Банк</td><td><strong><?= htmlspecialchars($paymentConfig['bank_name']) ?></strong></td></tr>
                                            <tr><td>Дансны нэр</td><td><?= htmlspecialchars($paymentConfig['account_name']) ?></td></tr>
                                            <tr><td>Дансны дугаар</td><td><strong><?= htmlspecialchars($paymentConfig['account_number']) ?></strong></td></tr>
                                        </table>
                                        <p class="bank-note">Шилжүүлсний дараа утасны дугаараа доор оруулна уу. (Гүйлгээний утгад утасны дугаар бичнэ)</p>
                                    </div>
                                    <div class="form-group">
                                        <label>Утасны дугаар <span class="required">*</span></label>
                                        <input type="tel" name="transaction_ref" class="form-control phone-input" placeholder="Жишээ: 99119911">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Нэмэлт тайлбар (заавал биш)</label>
                                    <textarea name="note" class="form-control" rows="2" placeholder="Тайлбар..."></textarea>
                                </div>

                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-paper-plane"></i> Төлбөр төлөх хүсэлт илгээх
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
document.querySelectorAll('input[name="payment_method"]').forEach(function(radio) {
    radio.addEventListener('change', function() {
        var form = this.closest('form');
        var bankDetails = form.querySelector('.bank-details');
        var phoneInput = form.querySelector('.phone-input');
        if (bankDetails) bankDetails.style.display = this.value === 'bank_transfer' ? 'block' : 'none';
        if (phoneInput) {
            if (this.value === 'bank_transfer') phoneInput.setAttribute('required', 'required');
            else phoneInput.removeAttribute('required');
        }
    });
});
document.querySelectorAll('form.payment-form').forEach(function(form) {
    form.addEventListener('submit', function(e) {
        var method = form.querySelector('input[name="payment_method"]:checked');
        var phoneInput = form.querySelector('.phone-input');
        if (method && method.value === 'bank_transfer' && phoneInput && !phoneInput.value.trim()) {
            e.preventDefault();
            alert('Дансаар шилжүүлэхэд утасны дугаар оруулна уу.');
            phoneInput.focus();
            return false;
        }
    });
});
<?php if ($scrollBookingId): ?>
(function() {
    var el = document.getElementById('booking-<?= $scrollBookingId ?>');
    if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.style.animation = 'payment-card-highlight 1.5s ease';
    }
})();
<?php endif; ?>
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
