<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function getBaseUrl() {
    if (strpos($_SERVER['DOCUMENT_ROOT'] ?? '', 'htdocs') !== false) {
        return '/altantuya';
    }
    return '';
}

function isLoggedIn() {
    return isset($_SESSION['user']);
}

function isAdmin() {
    return isLoggedIn() && $_SESSION['user']['role'] === 'admin';
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . getBaseUrl() . '/pages/login.php');
        exit;
    }
}

function requireAdmin() {
    if (!isAdmin()) {
        header('Location: ' . getBaseUrl() . '/pages/login.php');
        exit;
    }
}

function currentUser() {
    return $_SESSION['user'] ?? null;
}
