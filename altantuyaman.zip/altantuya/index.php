<?php
$pageTitle = 'Алтантуяа Караоке - Нүүр';
require_once __DIR__ . '/includes/header.php';

$rooms = $db->query('SELECT * FROM rooms ORDER BY created_at DESC')->fetchAll();

foreach ($rooms as &$room) {
    $imgStmt = $db->prepare('SELECT * FROM room_images WHERE room_id = ?');
    $imgStmt->execute([$room['id']]);
    $room['images'] = $imgStmt->fetchAll();
}
unset($room);
?>

<section class="hero">
    <div class="container">
        <div class="hero-content">
            <h1>Алтантуяа <span class="text-gradient">Караоке</span></h1>
            <p class="hero-subtitle">Найз нөхөд, гэр бүлийнхэнтэйгээ хамтдаа дуулж, мартагдашгүй мөчүүдийг бүтээгээрэй</p>
            <a href="#rooms" class="btn btn-primary btn-lg">
                <i class="fas fa-door-open"></i> Өрөөнүүдийг үзэх
            </a>
        </div>
    </div>
</section>

<section id="rooms" class="section">
    <div class="container">
        <div class="section-header">
            <h2>Манай өрөөнүүд</h2>
            <p>Таны сонголтод нийцсэн өрөөг сонгоорой</p>
        </div>

        <?php if (empty($rooms)): ?>
            <div class="empty-state">
                <i class="fas fa-music"></i>
                <h3>Одоогоор өрөө бүртгэгдээгүй байна</h3>
                <p>Удахгүй шинэ өрөөнүүд нэмэгдэнэ</p>
            </div>
        <?php else: ?>
            <div class="rooms-grid">
                <?php foreach ($rooms as $room): ?>
                    <div class="room-card">
                        <div class="room-card-image">
                            <?php if ($room['featured_image']): ?>
                                <img src="<?= $baseUrl ?>/uploads/rooms/<?= htmlspecialchars($room['featured_image']) ?>" alt="<?= htmlspecialchars($room['name']) ?>">
                            <?php else: ?>
                                <div class="room-card-placeholder">
                                    <i class="fas fa-microphone-alt"></i>
                                </div>
                            <?php endif; ?>
                            <div class="room-card-price">
                                <span><?= number_format($room['price']) ?>₮</span>
                            </div>
                        </div>
                        <div class="room-card-body">
                            <h3><?= htmlspecialchars($room['name']) ?></h3>
                            <p><?= mb_substr(htmlspecialchars($room['description']), 0, 100) ?>...</p>
                            <a href="<?= $baseUrl ?>/pages/room-detail.php?id=<?= $room['id'] ?>" class="btn btn-outline btn-block">
                                Дэлгэрэнгүй үзэх <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
