<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';

$baseUrl = '';
if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/altantuya')) {
    $baseUrl = '/altantuya';
}
?>
<!DOCTYPE html>
<html lang="mn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'Караоке' ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>/assets/css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="container nav-container">
            <a href="<?= $baseUrl ?>/" class="logo">
                <i class="fas fa-microphone-alt"></i>
                <span>Алтантуяа Караоке</span>
            </a>
            <div class="nav-links">
                <a href="<?= $baseUrl ?>/" class="nav-link">
                    <i class="fas fa-home"></i> Нүүр
                </a>
                <?php if (isLoggedIn()): ?>
                    <?php if (isAdmin()): ?>
                        <a href="<?= $baseUrl ?>/pages/admin/dashboard.php" class="nav-link">
                            <i class="fas fa-tachometer-alt"></i> Админ
                        </a>
                    <?php endif; ?>
                    <div class="nav-user">
                        <span class="nav-username">
                            <i class="fas fa-user-circle"></i>
                            <?= htmlspecialchars($_SESSION['user']['username']) ?>
                        </span>
                        <a href="<?= $baseUrl ?>/pages/logout.php" class="btn btn-sm btn-outline">Гарах</a>
                    </div>
                <?php else: ?>
                    <a href="<?= $baseUrl ?>/pages/login.php" class="nav-link">
                        <i class="fas fa-sign-in-alt"></i> Нэвтрэх
                    </a>
                    <a href="<?= $baseUrl ?>/pages/register.php" class="btn btn-primary btn-sm">Бүртгүүлэх</a>
                <?php endif; ?>
            </div>
            <button class="mobile-toggle" onclick="document.querySelector('.nav-links').classList.toggle('active')">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </nav>
    <main class="main-content">
