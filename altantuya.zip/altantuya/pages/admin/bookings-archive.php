<?php
$pageTitle = 'Админ - Архив';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/database.php';
requireAdmin();

$base = getBaseUrl();

if (isset($_GET['delete_permanent'])) {
    $bId = intval($_GET['delete_permanent']);
    $db->prepare('DELETE FROM bookings WHERE id = ? AND archived = 1')->execute([$bId]);
    header('Location: ' . $base . '/pages/admin/bookings-archive.php?deleted=1');
    exit;
}

if (isset($_GET['delete_all'])) {
    $db->prepare('DELETE FROM bookings WHERE archived = 1')->execute();
    header('Location: ' . $base . '/pages/admin/bookings-archive.php?deleted_all=1');
    exit;
}

if (isset($_GET['restore'])) {
    $bId = intval($_GET['restore']);
    $db->prepare('UPDATE bookings SET archived = 0 WHERE id = ? AND archived = 1')->execute([$bId]);
    header('Location: ' . $base . '/pages/admin/bookings-archive.php?restored=1');
    exit;
}

$archived = $db->query("
    SELECT b.*, u.username, u.fullname, r.name as room_name
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN rooms r ON b.room_id = r.id
    WHERE b.archived = 1
    ORDER BY b.created_at DESC
")->fetchAll();

$statusLabels = [
    'pending' => ['Хүлээгдэж буй', 'badge-pending'],
    'confirmed' => ['Баталгаажсан', 'badge-confirmed'],
    'completed' => ['Дууссан', 'badge-completed'],
    'cancelled' => ['Цуцлагдсан', 'badge-cancelled']
];

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container">
    <div class="admin-page">
        <?php include __DIR__ . '/../../includes/admin-sidebar.php'; ?>

        <div class="admin-content">
            <div class="admin-content-header">
                <h1 class="admin-title"><i class="fas fa-archive"></i> Архивласан захиалгууд</h1>
                <div style="display: flex; gap: 8px;">
                    <a href="<?= $baseUrl ?>/pages/admin/bookings.php" class="btn btn-outline">
                        <i class="fas fa-arrow-left"></i> Захиалга руу буцах
                    </a>
                    <?php if (!empty($archived)): ?>
                    <a href="<?= $baseUrl ?>/pages/admin/bookings-archive.php?delete_all=1"
                       class="btn btn-danger"
                       onclick="return confirm('АНХААРУУЛГА!\n\nБүх архивласан захиалгуудыг бүрмөсөн устгах уу?\nЭнэ үйлдлийг буцаах БОЛОМЖГҮЙ!')">
                        <i class="fas fa-trash"></i> Бүгдийг устгах
                    </a>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (isset($_GET['deleted'])): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> Захиалга бүрмөсөн устгагдлаа</div>
            <?php endif; ?>
            <?php if (isset($_GET['deleted_all'])): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> Бүх архив устгагдлаа</div>
            <?php endif; ?>
            <?php if (isset($_GET['restored'])): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> Захиалга сэргээгдлээ</div>
            <?php endif; ?>

            <div class="alert alert-danger" style="margin-bottom: 20px;">
                <i class="fas fa-exclamation-triangle"></i>
                <div>
                    <strong>Анхаар!</strong> Архиваас устгасан захиалгыг дахин сэргээх <strong>БОЛОМЖГҮЙ</strong>.
                    Архиваас устгахаасаа өмнө сайтар бодоорой.
                </div>
            </div>

            <?php if (empty($archived)): ?>
                <div class="empty-state">
                    <i class="fas fa-archive"></i>
                    <h3>Архив хоосон байна</h3>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Хэрэглэгч</th>
                                <th>Өрөө</th>
                                <th>Огноо</th>
                                <th>Цаг</th>
                                <th>Нийт үнэ</th>
                                <th>Төлөв</th>
                                <th>Үйлдэл</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($archived as $i => $b): ?>
                            <tr style="opacity: 0.8;">
                                <td><?= $i + 1 ?></td>
                                <td><?= htmlspecialchars($b['fullname'] ?? $b['username']) ?></td>
                                <td><?= htmlspecialchars($b['room_name']) ?></td>
                                <td><?= $b['booking_date'] ?></td>
                                <td><?= $b['start_time'] ?> - <?= $b['end_time'] ?></td>
                                <td><?= number_format($b['total_price']) ?>₮</td>
                                <td>
                                    <?php $sl = $statusLabels[$b['status']] ?? ['?', 'badge-user']; ?>
                                    <span class="badge <?= $sl[1] ?>"><?= $sl[0] ?></span>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="<?= $baseUrl ?>/pages/admin/bookings-archive.php?restore=<?= $b['id'] ?>"
                                           class="btn btn-sm btn-outline" title="Сэргээх">
                                            <i class="fas fa-undo"></i>
                                        </a>
                                        <a href="<?= $baseUrl ?>/pages/admin/bookings-archive.php?delete_permanent=<?= $b['id'] ?>"
                                           class="btn btn-sm btn-danger" title="Бүрмөсөн устгах"
                                           onclick="return confirm('АНХААРУУЛГА!\n\nЭнэ захиалгыг бүрмөсөн устгах уу?\nДахин сэргээх БОЛОМЖГҮЙ!')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
