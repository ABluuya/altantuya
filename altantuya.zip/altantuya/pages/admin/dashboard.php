<?php
$pageTitle = 'Админ - Хянах самбар';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/database.php';
requireAdmin();

$totalUsers = $db->query("SELECT COUNT(*) as cnt FROM users WHERE role='user'")->fetch()['cnt'];
$totalRooms = $db->query("SELECT COUNT(*) as cnt FROM rooms")->fetch()['cnt'];
$totalProducts = $db->query("SELECT COUNT(*) as cnt FROM products")->fetch()['cnt'];
$totalBookings = $db->query("SELECT COUNT(*) as cnt FROM bookings")->fetch()['cnt'];
$pendingBookings = $db->query("SELECT COUNT(*) as cnt FROM bookings WHERE status='pending'")->fetch()['cnt'];

$period = $_GET['period'] ?? 'all';
$periodLabel = 'Нийт';
$dateCondition = '';

switch ($period) {
    case 'week':
        $dateCondition = "AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
        $periodLabel = 'Сүүлийн 7 хоног';
        break;
    case 'month':
        $dateCondition = "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)";
        $periodLabel = 'Сүүлийн 1 сар';
        break;
    case 'year':
        $dateCondition = "AND created_at >= DATE_SUB(NOW(), INTERVAL 1 YEAR)";
        $periodLabel = 'Сүүлийн 1 жил';
        break;
}

$roomRevenue = $db->query("SELECT COALESCE(SUM(total_price),0) as total FROM bookings WHERE status = 'completed' $dateCondition")->fetch()['total'];
$productRevenue = $db->query("SELECT COALESCE(SUM(total_price),0) as total FROM orders WHERE status = 'completed' $dateCondition")->fetch()['total'];
$totalRevenue = $roomRevenue + $productRevenue;

$completedBookings = $db->query("SELECT COUNT(*) as cnt FROM bookings WHERE status = 'completed' $dateCondition")->fetch()['cnt'];
$completedOrders = $db->query("SELECT COUNT(*) as cnt FROM orders WHERE status = 'completed' $dateCondition")->fetch()['cnt'];

$recentBookings = $db->query("
    SELECT b.*, u.username, u.fullname, r.name as room_name
    FROM bookings b JOIN users u ON b.user_id = u.id JOIN rooms r ON b.room_id = r.id
    ORDER BY b.created_at DESC LIMIT 5
")->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container">
    <div class="admin-page">
        <?php include __DIR__ . '/../../includes/admin-sidebar.php'; ?>

        <div class="admin-content">
            <h1 class="admin-title"><i class="fas fa-tachometer-alt"></i> Хянах самбар</h1>

            <div class="stats-grid">
                <div class="stat-card stat-rooms">
                    <div class="stat-icon"><i class="fas fa-door-open"></i></div>
                    <div class="stat-info">
                        <h3><?= $totalRooms ?></h3>
                        <p>Нийт өрөө</p>
                    </div>
                </div>
                <div class="stat-card stat-users">
                    <div class="stat-icon"><i class="fas fa-users"></i></div>
                    <div class="stat-info">
                        <h3><?= $totalUsers ?></h3>
                        <p>Нийт хэрэглэгч</p>
                    </div>
                </div>
                <div class="stat-card" style="border-left: 3px solid var(--primary-light);">
                    <div class="stat-icon" style="background: rgba(108,60,225,0.15); color: var(--primary-light);"><i class="fas fa-box"></i></div>
                    <div class="stat-info">
                        <h3><?= $totalProducts ?></h3>
                        <p>Нийт бараа</p>
                    </div>
                </div>
                <div class="stat-card" style="border-left: 3px solid var(--success);">
                    <div class="stat-icon" style="background: rgba(16,185,129,0.15); color: var(--success);"><i class="fas fa-calendar-check"></i></div>
                    <div class="stat-info">
                        <h3><?= $totalBookings ?></h3>
                        <p>Нийт захиалга</p>
                    </div>
                </div>
                <div class="stat-card" style="border-left: 3px solid #F59E0B;">
                    <div class="stat-icon" style="background: rgba(245,158,11,0.15); color: #F59E0B;"><i class="fas fa-clock"></i></div>
                    <div class="stat-info">
                        <h3><?= $pendingBookings ?></h3>
                        <p>Хүлээгдэж буй</p>
                    </div>
                </div>
            </div>

            <div class="revenue-section">
                <div class="revenue-header">
                    <h2><i class="fas fa-chart-line"></i> Орлогын мэдээлэл</h2>
                    <div class="revenue-period-tabs">
                        <a href="<?= $baseUrl ?>/pages/admin/dashboard.php?period=week" class="period-tab <?= $period === 'week' ? 'active' : '' ?>">7 хоног</a>
                        <a href="<?= $baseUrl ?>/pages/admin/dashboard.php?period=month" class="period-tab <?= $period === 'month' ? 'active' : '' ?>">1 сар</a>
                        <a href="<?= $baseUrl ?>/pages/admin/dashboard.php?period=year" class="period-tab <?= $period === 'year' ? 'active' : '' ?>">1 жил</a>
                        <a href="<?= $baseUrl ?>/pages/admin/dashboard.php?period=all" class="period-tab <?= $period === 'all' ? 'active' : '' ?>">Бүгд</a>
                    </div>
                </div>

                <div class="revenue-cards">
                    <div class="revenue-card revenue-total">
                        <div class="revenue-card-icon">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <div class="revenue-card-info">
                            <span class="revenue-card-label"><?= $periodLabel ?> нийт орлого</span>
                            <span class="revenue-card-amount"><?= number_format($totalRevenue) ?>₮</span>
                            <span class="revenue-card-sub"><?= $completedBookings ?> захиалга, <?= $completedOrders ?> борлуулалт</span>
                        </div>
                    </div>
                    <div class="revenue-card revenue-room">
                        <div class="revenue-card-icon">
                            <i class="fas fa-door-open"></i>
                        </div>
                        <div class="revenue-card-info">
                            <span class="revenue-card-label">Өрөөний орлого</span>
                            <span class="revenue-card-amount"><?= number_format($roomRevenue) ?>₮</span>
                            <span class="revenue-card-sub"><?= $completedBookings ?> дууссан захиалга</span>
                        </div>
                    </div>
                    <div class="revenue-card revenue-product">
                        <div class="revenue-card-icon">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <div class="revenue-card-info">
                            <span class="revenue-card-label">Барааны орлого</span>
                            <span class="revenue-card-amount"><?= number_format($productRevenue) ?>₮</span>
                            <span class="revenue-card-sub"><?= $completedOrders ?> дууссан борлуулалт</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="admin-quick-actions">
                <h2>Түргэн үйлдлүүд</h2>
                <div class="quick-actions-grid">
                    <a href="<?= $baseUrl ?>/pages/admin/room-create.php" class="quick-action-card">
                        <i class="fas fa-plus-circle"></i>
                        <span>Шинэ өрөө нэмэх</span>
                    </a>
                    <a href="<?= $baseUrl ?>/pages/admin/product-create.php" class="quick-action-card">
                        <i class="fas fa-box"></i>
                        <span>Шинэ бараа нэмэх</span>
                    </a>
                    <a href="<?= $baseUrl ?>/pages/admin/bookings.php" class="quick-action-card">
                        <i class="fas fa-calendar-check"></i>
                        <span>Захиалга харах</span>
                    </a>
                    <a href="<?= $baseUrl ?>/pages/admin/users.php" class="quick-action-card">
                        <i class="fas fa-user-cog"></i>
                        <span>Хэрэглэгчид харах</span>
                    </a>
                </div>
            </div>

            <?php if (!empty($recentBookings)): ?>
            <div style="margin-top: 32px;">
                <h2 style="font-size: 1.2rem; font-weight: 700; color: var(--text-heading); margin-bottom: 16px;">
                    <i class="fas fa-history" style="color: var(--primary-light);"></i> Сүүлийн захиалгууд
                </h2>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Хэрэглэгч</th>
                                <th>Өрөө</th>
                                <th>Огноо</th>
                                <th>Цаг</th>
                                <th>Төлөв</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $statusLabels = [
                                'pending' => ['Хүлээгдэж буй', 'badge-pending'],
                                'confirmed' => ['Баталгаажсан', 'badge-confirmed'],
                                'completed' => ['Дууссан', 'badge-completed'],
                                'cancelled' => ['Цуцлагдсан', 'badge-cancelled']
                            ];
                            foreach ($recentBookings as $b):
                                $sl = $statusLabels[$b['status']] ?? ['?', 'badge-user'];
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($b['fullname'] ?? $b['username']) ?></td>
                                <td><?= htmlspecialchars($b['room_name']) ?></td>
                                <td><?= $b['booking_date'] ?></td>
                                <td><?= $b['start_time'] ?> - <?= $b['end_time'] ?></td>
                                <td><span class="badge <?= $sl[1] ?>"><?= $sl[0] ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
