<?php
$pageTitle = 'Админ - Өрөөнүүд';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/database.php';
requireAdmin();

if (isset($_GET['delete'])) {
    $deleteId = intval($_GET['delete']);
    $room = $db->prepare('SELECT * FROM rooms WHERE id = ?');
    $room->execute([$deleteId]);
    $roomData = $room->fetch();

    if ($roomData) {
        if ($roomData['featured_image'] && file_exists(__DIR__ . '/../../uploads/rooms/' . $roomData['featured_image'])) {
            unlink(__DIR__ . '/../../uploads/rooms/' . $roomData['featured_image']);
        }
        $imgs = $db->prepare('SELECT * FROM room_images WHERE room_id = ?');
        $imgs->execute([$deleteId]);
        foreach ($imgs->fetchAll() as $img) {
            $imgPath = __DIR__ . '/../../uploads/rooms/' . $img['image_path'];
            if (file_exists($imgPath)) unlink($imgPath);
        }
        $db->prepare('DELETE FROM rooms WHERE id = ?')->execute([$deleteId]);
    }
    header('Location: ' . getBaseUrl() . '/pages/admin/rooms.php?deleted=1');
    exit;
}

$rooms = $db->query('SELECT * FROM rooms ORDER BY created_at DESC')->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container">
    <div class="admin-page">
        <?php include __DIR__ . '/../../includes/admin-sidebar.php'; ?>

        <div class="admin-content">
            <div class="admin-content-header">
                <h1 class="admin-title">
                    <i class="fas fa-door-open"></i> Өрөөнүүд
                </h1>
                <a href="<?= $baseUrl ?>/pages/admin/room-create.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Шинэ өрөө нэмэх
                </a>
            </div>

            <?php if (isset($_GET['deleted'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> Өрөө амжилттай устгагдлаа
                </div>
            <?php endif; ?>
            <?php if (isset($_GET['created'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> Өрөө амжилттай нэмэгдлээ
                </div>
            <?php endif; ?>
            <?php if (isset($_GET['updated'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> Өрөөний мэдээлэл шинэчлэгдлээ
                </div>
            <?php endif; ?>

            <?php if (empty($rooms)): ?>
                <div class="empty-state">
                    <i class="fas fa-door-open"></i>
                    <h3>Өрөө бүртгэгдээгүй байна</h3>
                    <a href="<?= $baseUrl ?>/pages/admin/room-create.php" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Эхний өрөөгөө нэмэх
                    </a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Зураг</th>
                                <th>Нэр</th>
                                <th>Үнэ</th>
                                <th>Огноо</th>
                                <th>Үйлдэл</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rooms as $room): ?>
                            <tr>
                                <td>
                                    <?php if ($room['featured_image']): ?>
                                        <img src="<?= $baseUrl ?>/uploads/rooms/<?= htmlspecialchars($room['featured_image']) ?>"
                                             class="table-thumb" alt="">
                                    <?php else: ?>
                                        <div class="table-thumb-placeholder">
                                            <i class="fas fa-image"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><strong><?= htmlspecialchars($room['name']) ?></strong></td>
                                <td><?= number_format($room['price']) ?>₮</td>
                                <td><?= date('Y-m-d', strtotime($room['created_at'])) ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="<?= $baseUrl ?>/pages/admin/room-edit.php?id=<?= $room['id'] ?>"
                                           class="btn btn-sm btn-outline" title="Засах">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="<?= $baseUrl ?>/pages/admin/rooms.php?delete=<?= $room['id'] ?>"
                                           class="btn btn-sm btn-danger"
                                           onclick="return confirm('Энэ өрөөг устгах уу?')" title="Устгах">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
