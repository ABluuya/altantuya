function previewFeaturedImage(input) {
    const preview = document.getElementById('featuredPreview');
    const placeholder = document.getElementById('featuredPlaceholder');
    const previewImg = document.getElementById('featuredPreviewImg');

    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewImg.src = e.target.result;
            preview.style.display = 'block';
            placeholder.style.display = 'none';
        };
        reader.readAsDataURL(input.files[0]);
    }
}

function removeFeaturedImage() {
    const preview = document.getElementById('featuredPreview');
    const placeholder = document.getElementById('featuredPlaceholder');
    const input = document.getElementById('featured_image');

    preview.style.display = 'none';
    placeholder.style.display = 'block';
    input.value = '';
}

function previewOtherImages(input) {
    const container = document.getElementById('otherPreviews');
    container.innerHTML = '';

    if (input.files) {
        Array.from(input.files).forEach((file, i) => {
            const reader = new FileReader();
            reader.onload = function(e) {
                const div = document.createElement('div');
                div.className = 'preview-item';
                div.innerHTML = '<img src="' + e.target.result + '" alt="Зураг ' + (i + 1) + '">';
                container.appendChild(div);
            };
            reader.readAsDataURL(file);
        });

        const placeholder = document.getElementById('otherPlaceholder');
        if (placeholder) {
            placeholder.innerHTML = '<i class="fas fa-check-circle"></i><p>' + input.files.length + ' зураг сонгогдлоо</p><span>Өөр зураг сонгох бол дахин дарна уу</span>';
        }
    }
}

function changeMainImage(thumb) {
    const mainImg = document.getElementById('mainImage');
    if (!mainImg) return;

    const thumbImg = thumb.querySelector('img');
    mainImg.src = thumbImg.src;

    document.querySelectorAll('.gallery-thumb').forEach(t => t.classList.remove('active'));
    thumb.classList.add('active');
}

document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert-success');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s ease';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 4000);
    });
});
