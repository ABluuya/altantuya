<?php
$pageTitle = 'Хуудас олдсонгүй';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="container">
    <div class="empty-state" style="padding: 80px 0;">
        <i class="fas fa-search" style="font-size: 4rem;"></i>
        <h2>404 - Хуудас олдсонгүй</h2>
        <p>Таны хайсан хуудас олдсонгүй</p>
        <a href="<?= $baseUrl ?>/" class="btn btn-primary">
            <i class="fas fa-home"></i> Нүүр хуудас руу буцах
        </a>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
