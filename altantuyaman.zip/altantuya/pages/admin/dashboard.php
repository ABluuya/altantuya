<?php
$pageTitle = 'Админ - Хянах самбар';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/database.php';
requireAdmin();

$totalUsers = $db->query("SELECT COUNT(*) as cnt FROM users WHERE role='user'")->fetch()['cnt'];
$totalRooms = $db->query("SELECT COUNT(*) as cnt FROM rooms")->fetch()['cnt'];

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container">
    <div class="admin-page">
        <div class="admin-sidebar">
            <div class="sidebar-header">
                <i class="fas fa-crown"></i>
                <h3>Админ цэс</h3>
            </div>
            <nav class="sidebar-nav">
                <a href="<?= $baseUrl ?>/pages/admin/dashboard.php" class="sidebar-link active">
                    <i class="fas fa-tachometer-alt"></i> Хянах самбар
                </a>
                <a href="<?= $baseUrl ?>/pages/admin/rooms.php" class="sidebar-link">
                    <i class="fas fa-door-open"></i> Өрөөнүүд
                </a>
                <a href="<?= $baseUrl ?>/pages/admin/users.php" class="sidebar-link">
                    <i class="fas fa-users"></i> Хэрэглэгчид
                </a>
            </nav>
        </div>

        <div class="admin-content">
            <h1 class="admin-title">Хянах самбар</h1>

            <div class="stats-grid">
                <div class="stat-card stat-rooms">
                    <div class="stat-icon"><i class="fas fa-door-open"></i></div>
                    <div class="stat-info">
                        <h3><?= $totalRooms ?></h3>
                        <p>Нийт өрөө</p>
                    </div>
                </div>
                <div class="stat-card stat-users">
                    <div class="stat-icon"><i class="fas fa-users"></i></div>
                    <div class="stat-info">
                        <h3><?= $totalUsers ?></h3>
                        <p>Нийт хэрэглэгч</p>
                    </div>
                </div>
            </div>

            <div class="admin-quick-actions">
                <h2>Түргэн үйлдлүүд</h2>
                <div class="quick-actions-grid">
                    <a href="<?= $baseUrl ?>/pages/admin/room-create.php" class="quick-action-card">
                        <i class="fas fa-plus-circle"></i>
                        <span>Шинэ өрөө нэмэх</span>
                    </a>
                    <a href="<?= $baseUrl ?>/pages/admin/rooms.php" class="quick-action-card">
                        <i class="fas fa-list"></i>
                        <span>Өрөөнүүд удирдах</span>
                    </a>
                    <a href="<?= $baseUrl ?>/pages/admin/users.php" class="quick-action-card">
                        <i class="fas fa-user-cog"></i>
                        <span>Хэрэглэгчид харах</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
