<?php
$pageTitle = 'Админ - Шинэ бараа нэмэх';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/database.php';
requireAdmin();

$base = getBaseUrl();
$error = '';
$categories = $db->query('SELECT * FROM categories ORDER BY name')->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = trim($_POST['code'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $price = intval($_POST['price'] ?? 0);
    $category_id = intval($_POST['category_id'] ?? 0) ?: null;
    $description = trim($_POST['description'] ?? '');
    $stock = intval($_POST['stock'] ?? 0);
    $status = $_POST['status'] ?? 'active';

    if (empty($code) || empty($name) || $price <= 0) {
        $error = 'Барааны код, нэр, үнийг зөв оруулна уу';
    } else {
        $dup = $db->prepare('SELECT id FROM products WHERE code = ?');
        $dup->execute([$code]);
        if ($dup->fetch()) {
            $error = 'Энэ код бүртгэлтэй байна. Өөр код оруулна уу.';
        } else {
            $image = null;
            $uploadDir = __DIR__ . '/../../uploads/products/';

            if (!empty($_FILES['image']['name'])) {
                $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                if (in_array($ext, $allowed)) {
                    $image = 'prod_' . time() . '_' . uniqid() . '.' . $ext;
                    move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $image);
                }
            }

            $stmt = $db->prepare('INSERT INTO products (code, category_id, name, price, description, image, stock, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute([$code, $category_id, $name, $price, $description, $image, $stock, $status]);

            header('Location: ' . $base . '/pages/admin/products.php?created=1');
            exit;
        }
    }
}

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container">
    <div class="admin-page">
        <?php include __DIR__ . '/../../includes/admin-sidebar.php'; ?>

        <div class="admin-content">
            <div class="admin-content-header">
                <h1 class="admin-title"><i class="fas fa-plus-circle"></i> Шинэ бараа нэмэх</h1>
                <a href="<?= $baseUrl ?>/pages/admin/products.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Буцах</a>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= $error ?></div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" class="room-form">
                <div class="form-card">
                    <h3><i class="fas fa-info-circle"></i> Барааны мэдээлэл</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Барааны код <span class="required">*</span></label>
                            <input type="text" name="code" class="form-control" required placeholder="Жишээ: BR001"
                                   value="<?= htmlspecialchars($_POST['code'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>Барааны нэр <span class="required">*</span></label>
                            <input type="text" name="name" class="form-control" required placeholder="Жишээ: Кока Кола"
                                   value="<?= htmlspecialchars($_POST['name'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Үнэ (₮) <span class="required">*</span></label>
                            <input type="number" name="price" class="form-control" required min="1" placeholder="5000"
                                   value="<?= htmlspecialchars($_POST['price'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>Ангилал</label>
                            <select name="category_id" class="form-control">
                                <option value="">-- Сонгох --</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= $cat['id'] ?>" <?= ($_POST['category_id'] ?? '') == $cat['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($cat['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Нөөцийн тоо</label>
                            <input type="number" name="stock" class="form-control" min="0" placeholder="0"
                                   value="<?= htmlspecialchars($_POST['stock'] ?? '0') ?>">
                        </div>
                        <div class="form-group">
                            <label>Төлөв</label>
                            <select name="status" class="form-control">
                                <option value="active">Идэвхтэй</option>
                                <option value="inactive">Идэвхгүй</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Тайлбар</label>
                        <textarea name="description" class="form-control" rows="3" placeholder="Барааны тухай тайлбар"><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
                    </div>
                </div>

                <div class="form-card">
                    <h3><i class="fas fa-image"></i> Барааны зураг</h3>
                    <div class="upload-area" id="featuredUploadArea">
                        <input type="file" id="featured_image" name="image" accept="image/*" onchange="previewFeaturedImage(this)">
                        <div class="upload-placeholder" id="featuredPlaceholder">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <p>Зураг сонгоно уу</p>
                            <span>JPG, PNG, GIF, WEBP</span>
                        </div>
                        <div class="upload-preview" id="featuredPreview" style="display:none;">
                            <img id="featuredPreviewImg" src="" alt="">
                            <button type="button" class="btn btn-sm btn-danger remove-preview" onclick="removeFeaturedImage()"><i class="fas fa-times"></i></button>
                        </div>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-save"></i> Хадгалах</button>
                    <a href="<?= $baseUrl ?>/pages/admin/products.php" class="btn btn-outline btn-lg">Цуцлах</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
