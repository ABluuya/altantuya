<?php
$pageTitle = 'Админ - Тохиргоо';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/settings.php';
requireAdmin();

$base = getBaseUrl();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $section = $_POST['section'] ?? '';
    if ($section === 'contact') {
        setSetting('contact_phone', trim($_POST['contact_phone'] ?? ''));
        setSetting('contact_phone_display', trim($_POST['contact_phone_display'] ?? ''));
        setSetting('contact_google_maps', trim($_POST['contact_google_maps'] ?? ''));
        $success = 'Холбоо барих мэдээлэл шинэчлэгдлээ';
    } elseif ($section === 'payment') {
        setSetting('payment_bank_name', trim($_POST['bank_name'] ?? ''));
        setSetting('payment_account_name', trim($_POST['account_name'] ?? ''));
        setSetting('payment_account_number', trim($_POST['account_number'] ?? ''));
        setSetting('payment_bank_code', trim($_POST['bank_code'] ?? ''));
        $success = 'Дансны мэдээлэл шинэчлэгдлээ';
    }
}

$contact = getContactConfig();
$payment = getPaymentConfig();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container">
    <div class="admin-page">
        <?php include __DIR__ . '/../../includes/admin-sidebar.php'; ?>

        <div class="admin-content">
            <h1 class="admin-title"><i class="fas fa-cog"></i> Тохиргоо</h1>

            <?php if ($success): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= $success ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= $error ?></div>
            <?php endif; ?>

            <div class="form-card" style="margin-bottom: 24px;">
                <h3><i class="fas fa-phone-alt"></i> Холбоо барих</h3>
                <form method="POST">
                    <input type="hidden" name="section" value="contact">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Утасны дугаар</label>
                            <input type="text" name="contact_phone" class="form-control" placeholder="99119911"
                                   value="<?= htmlspecialchars($contact['phone']) ?>">
                        </div>
                        <div class="form-group">
                            <label>Харуулах дугаар</label>
                            <input type="text" name="contact_phone_display" class="form-control" placeholder="9911-9911"
                                   value="<?= htmlspecialchars($contact['phone_display']) ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Google Maps Embed URL</label>
                        <textarea name="contact_google_maps" class="form-control" rows="3" placeholder="https://www.google.com/maps/embed?pb=..."><?= htmlspecialchars($contact['google_maps_embed']) ?></textarea>
                        <small style="color: var(--text-muted);">Google Maps → Share → Embed a map-аас хуулна</small>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Хадгалах</button>
                </form>
            </div>

            <div class="form-card" style="margin-bottom: 24px;">
                <h3><i class="fas fa-university"></i> Дансны мэдээлэл</h3>
                <p style="color: var(--text-muted); margin-bottom: 16px;">Төлбөр төлөх хуудсанд дансаар шилжүүлэхэд харагдах мэдээлэл</p>
                <form method="POST">
                    <input type="hidden" name="section" value="payment">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Банкны нэр</label>
                            <input type="text" name="bank_name" class="form-control" placeholder="Хаан Банк"
                                   value="<?= htmlspecialchars($payment['bank_name']) ?>">
                        </div>
                        <div class="form-group">
                            <label>Дансны нэр</label>
                            <input type="text" name="account_name" class="form-control" placeholder="Алтантуяа Караоке"
                                   value="<?= htmlspecialchars($payment['account_name']) ?>">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Дансны дугаар</label>
                            <input type="text" name="account_number" class="form-control" placeholder="1234567890"
                                   value="<?= htmlspecialchars($payment['account_number']) ?>">
                        </div>
                        <div class="form-group">
                            <label>Банкны код</label>
                            <input type="text" name="bank_code" class="form-control" placeholder="050000"
                                   value="<?= htmlspecialchars($payment['bank_code']) ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Хадгалах</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
