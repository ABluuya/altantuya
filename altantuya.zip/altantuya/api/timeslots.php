<?php
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json; charset=utf-8');

if (!isLoggedIn()) {
    echo json_encode(['success' => false]);
    exit;
}

$roomId = intval($_GET['room_id'] ?? 0);
$date = $_GET['date'] ?? '';

if (!$roomId || !$date) {
    echo json_encode(['success' => false, 'message' => 'room_id, date шаардлагатай']);
    exit;
}

$booked = $db->prepare("
    SELECT start_time, end_time FROM bookings
    WHERE room_id = ? AND booking_date = ? AND status IN ('pending', 'confirmed')
");
$booked->execute([$roomId, $date]);
$bookings = $booked->fetchAll();

$bookedHours = [];
foreach ($bookings as $b) {
    $sh = intval(explode(':', $b['start_time'])[0]);
    $eh = intval(explode(':', $b['end_time'])[0]);
    for ($h = $sh; $h < $eh; $h++) {
        $bookedHours[] = $h;
    }
}

echo json_encode([
    'success' => true,
    'booked_hours' => array_values(array_unique($bookedHours))
]);
