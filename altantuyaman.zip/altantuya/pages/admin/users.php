<?php
$pageTitle = 'Админ - Хэрэглэгчид';
require_once __DIR__ . '/../../config/auth.php';
require_once __DIR__ . '/../../config/database.php';
requireAdmin();

$users = $db->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="container">
    <div class="admin-page">
        <div class="admin-sidebar">
            <div class="sidebar-header">
                <i class="fas fa-crown"></i>
                <h3>Админ цэс</h3>
            </div>
            <nav class="sidebar-nav">
                <a href="<?= $baseUrl ?>/pages/admin/dashboard.php" class="sidebar-link">
                    <i class="fas fa-tachometer-alt"></i> Хянах самбар
                </a>
                <a href="<?= $baseUrl ?>/pages/admin/rooms.php" class="sidebar-link">
                    <i class="fas fa-door-open"></i> Өрөөнүүд
                </a>
                <a href="<?= $baseUrl ?>/pages/admin/users.php" class="sidebar-link active">
                    <i class="fas fa-users"></i> Хэрэглэгчид
                </a>
            </nav>
        </div>

        <div class="admin-content">
            <h1 class="admin-title">
                <i class="fas fa-users"></i> Хэрэглэгчдийн жагсаалт
            </h1>

            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Нэвтрэх нэр</th>
                            <th>Утас</th>
                            <th>Эрх</th>
                            <th>Бүртгүүлсэн</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $i => $u): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td>
                                <div class="user-cell">
                                    <i class="fas fa-user-circle"></i>
                                    <span><?= htmlspecialchars($u['username']) ?></span>
                                </div>
                            </td>
                            <td><?= htmlspecialchars($u['phone'] ?? '-') ?></td>
                            <td>
                                <span class="badge badge-<?= $u['role'] === 'admin' ? 'admin' : 'user' ?>">
                                    <?= $u['role'] === 'admin' ? 'Админ' : 'Хэрэглэгч' ?>
                                </span>
                            </td>
                            <td><?= date('Y-m-d H:i', strtotime($u['created_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
